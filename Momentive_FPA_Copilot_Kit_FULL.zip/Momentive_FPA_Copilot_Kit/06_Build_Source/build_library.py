import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from prompts import LIB, LADDER, ANTIPATTERNS, STAGES
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.worksheet.table import Table, TableStyleInfo
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.utils import get_column_letter

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "kit", "05_Prompt_Library"); os.makedirs(OUT, exist_ok=True)
NAVY = "21295C"; F = "Calibri"
HDR = PatternFill("solid", fgColor=NAVY)
LV = {"L1": "FCE4D6", "L2": "FFF2CC", "L3": "E2EFDA", "L4": "DDEBF7"}

VERIFY = [
    ("V1", "Copilot in Excel offers Allow editing, Plan and Chat only modes; labs use Chat only on the controlled workbook.", "Version-sensitive", "Practitioner guide (iGears), interface checked 27 Aug 2026 - secondary source", "Open Copilot in Excel in the client tenant during dry-run; screenshot the mode selector."),
    ("V2", "Agent Mode in Excel is generally available (from about April 2026) and can take multi-step actions in workbooks.", "Version-sensitive", "JMCO article, June 2026 - secondary source", "Confirm in tenant; if absent, run MOM-P05/P17 with the standard Copilot pane or do the edit manually."),
    ("V3", "The =COPILOT(prompt, range...) worksheet function exists and returns text into cells.", "Version-sensitive", "Practitioner posts; not re-checked on Microsoft Learn for this build", "Type =COPILOT( in the tenant; check licence/update channel. Fallback: Copilot pane prompt MOM-P29."),
    ("V4", "Python in Excel reads ranges with xl(\"Sheet!A1:B2\", headers=True) and returns a DataFrame to the grid.", "Version-sensitive", "Trainer knowledge of Python in Excel; code tested locally with a stub xl()", "Run Lab 4 code in the tenant during dry-run. Fallback: formula PVM on the PVM sheet."),
    ("V5", "Excel Power Query 'From SAP HANA Database' needs the SAP HANA ODBC driver matching 32/64-bit Excel.", "Verified", "Microsoft Learn - SAP HANA database connector", "None for class (labs use CSV stand-ins)."),
    ("V6", "SAP BW Application Server connector needs SAP .NET Connector 3.0 or 3.1.", "Verified", "Microsoft Learn - SAP BW Application Server connector", "None for class."),
    ("V7", "Finance in Microsoft 365 Copilot offers variance analysis in Excel; SAP connector coverage by SAP edition.", "Unverified (SAP coverage)", "Microsoft Learn release plan; 2024 partner blog for SAP coverage", "Confirm licence and current ERP connector list with Microsoft account team before mentioning in class."),
    ("V8", "Copilot Studio can call SAP via the SAP OData connector or the SAP ERP connector through the on-premises data gateway.", "Version-sensitive", "Practitioner blog (holgerimbery) - secondary source", "Confirm connector availability with the client's Power Platform admin before Phase 3."),
    ("V9", "Agent Builder in Microsoft 365 Copilot can create declarative agents grounded on uploaded or SharePoint files.", "Version-sensitive", "Prior JP courseware (Walmart deck, Day 4)", "Build MOM-P38 agent in tenant during dry-run."),
    ("V10", "Copilot Cowork is available to the client and billed by usage.", "Unverified", "Prior JP courseware", "Treat Lab 8 Cowork step as optional until the tenant admin confirms."),
    ("V11", "Copilot in Excel works best when data is formatted as an Excel Table.", "Version-sensitive", "Microsoft guidance as known to the trainer", "Keep all data as tbl_* tables (already done)."),
    ("V12", "Time-saving / productivity percentages.", "Omitted by design", "Build principle: no unverified productivity claims", "Measure the client's own baseline (time per close step) before and after."),
]

def hdr(ws, row, cols):
    for j, c in enumerate(cols, 1):
        x = ws.cell(row=row, column=j, value=c)
        x.font = Font(name=F, size=11, bold=True, color="FFFFFF"); x.fill = HDR
        x.alignment = Alignment(wrap_text=True, vertical="center")

def full_prompt(p):
    if p["Surface"].startswith("=COPILOT") or p["ID"] == "MOM-P40":
        return p["A"]
    parts = [("Context", p["C"]), ("Role", p["R"]), ("Action", p["A"]), ("Format", p["F"]), ("Target & tone", p["T"])]
    return "\n".join(f"{k}: {v}" for k, v in parts if v)

wb = Workbook(); ws = wb.active; ws.title = "How to use"
ws["A1"] = "Momentive FP&A - CRAFT Prompt Library (Copilot for SAP + DW variance analysis)"
ws["A1"].font = Font(name=F, size=16, bold=True, color=NAVY)
rows = [
    ("Purpose", f"{len(LIB)} tested-shape prompts for the monthly variance cycle, mapped to lab exercises. Copy the 'Full prompt' column into the named Copilot surface."),
    ("Data", "All prompts refer to the fictional teaching workbook Momentive_Variance_Model (Sep 2026 close). Replace sheet/cell names when you use them on real data."),
    ("CRAFT", "C = Context (situation, data, constraints)   R = Role   A = Action (ONE task verb)   F = Format   T = Target & tone (audience, voice, grounding rules)."),
    ("Level 1", "Action + Format only. Fast, but Copilot fills the gaps with guesses. Use for exploration, never for numbers that leave the team."),
    ("Level 2", "+ Role and Context. Good for single, well-scoped questions."),
    ("Level 3", "All five elements, grounded on named sheets/tables, with 'use ONLY ... cite the cell ... say not available'. Default for anything that feeds the pack."),
    ("Level 4", "The same discipline written as reusable agent or delegation instructions: guardrails, refusal rules, stop conditions and a test set."),
    ("Golden rule", "Copilot explains and drafts; Power Query, formulas and Python produce the numbers. Every figure Copilot states is tied to a cell (MOM-P19, MOM-P31) before it is used."),
    ("Modes", "Controlled workbook = Copilot Chat only. Edits (Agent Mode / Allow editing) only on a working copy. See Verification Register V1-V2."),
    ("Columns", "Verify against = where the right answer lives. Risk = what goes wrong if you skip verification. Version-sensitive = feature behaviour may differ by tenant/date."),
    ("Prompt Log", "Use the Prompt Log sheet during labs: one row per prompt run, verified Yes/No, and what you changed. It becomes your team's playbook."),
]
for k, (a, b) in enumerate(rows, 3):
    ws.cell(row=k, column=1, value=a).font = Font(name=F, size=11, bold=True); ws.cell(row=k, column=2, value=b)
ws.column_dimensions["A"].width = 16; ws.column_dimensions["B"].width = 120

# ---- Library ----
lib = wb.create_sheet("Prompt Library")
cols = ["ID", "Stage", "Stage name", "Copilot surface", "CRAFT level", "Lab", "C - Context", "R - Role", "A - Action",
        "F - Format", "T - Target & tone", "Full prompt (copy this)", "Expected output", "Verify against", "Risk if unverified", "Version-sensitive?"]
hdr(lib, 1, cols)
for i, p in enumerate(LIB, 2):
    vals = [p["ID"], p["Stage"], p["StageName"], p["Surface"], p["Level"], p["Lab"], p["C"], p["R"], p["A"], p["F"], p["T"],
            full_prompt(p), p["Expected"], p["Verify"], p["Risk"], "Yes - see Verification Register" if p["VersionSensitive"] else "No"]
    for j, v in enumerate(vals, 1):
        c = lib.cell(row=i, column=j, value=v)
        if isinstance(v, str) and v.startswith("="): c.data_type = "s"   # prompt text, not a live formula
    lib.cell(row=i, column=5).fill = PatternFill("solid", fgColor=LV[p["Level"]])
t = Table(displayName="tbl_prompts", ref=f"A1:{get_column_letter(len(cols))}{len(LIB)+1}")
t.tableStyleInfo = TableStyleInfo(name="TableStyleLight9", showRowStripes=True); lib.add_table(t)
for j, w in enumerate([10, 6, 22, 26, 8, 12, 40, 30, 50, 34, 40, 70, 40, 34, 30, 16], 1):
    lib.column_dimensions[get_column_letter(j)].width = w
lib.freeze_panes = "B2"

# ---- Ladder ----
ld = wb.create_sheet("Level Ladder")
hdr(ld, 1, ["Task", "Level", "Prompt", "What changes from the level below"])
why = {"L1": "Baseline - action and format only.", "L2": "Adds who is asking and what data is in play.",
       "L3": "Adds grounding, citation and 'not available' rules - output becomes checkable.",
       "L4": "Becomes reusable instructions with guardrails and stop conditions."}
r = 2
for task, steps in LADDER:
    for lvl, txt in steps:
        for j, v in enumerate([task, lvl, txt, why[lvl]], 1): ld.cell(row=r, column=j, value=v)
        ld.cell(row=r, column=2).fill = PatternFill("solid", fgColor=LV[lvl]); r += 1
for j, w in enumerate([28, 8, 100, 45], 1): ld.column_dimensions[get_column_letter(j)].width = w

# ---- Anti-patterns ----
ap = wb.create_sheet("Anti-patterns")
hdr(ap, 1, ["Anti-pattern", "What goes wrong", "Do this instead"])
for i, row in enumerate(ANTIPATTERNS, 2):
    for j, v in enumerate(row, 1): ap.cell(row=i, column=j, value=v)
for j, w in enumerate([50, 50, 60], 1): ap.column_dimensions[get_column_letter(j)].width = w

# ---- Stages ----
st = wb.create_sheet("Stages")
hdr(st, 1, ["Stage", "Name", "Prompt count", "L1", "L2", "L3", "L4"])
for i, (k, v) in enumerate(STAGES.items(), 2):
    st.cell(row=i, column=1, value=k); st.cell(row=i, column=2, value=v)
    n = len(LIB) + 1
    st.cell(row=i, column=3, value=f"=COUNTIF('Prompt Library'!$B$2:$B${n},A{i})")
    for j, lvl in enumerate(["L1", "L2", "L3", "L4"], 4):
        st.cell(row=i, column=j, value=f"=COUNTIFS('Prompt Library'!$B$2:$B${n},$A{i},'Prompt Library'!$E$2:$E${n},\"{lvl}\")")
tr = len(STAGES) + 2
st.cell(row=tr, column=2, value="Total")
for j in range(3, 8):
    L = get_column_letter(j); st.cell(row=tr, column=j, value=f"=SUM({L}2:{L}{tr-1})")
for j, w in enumerate([8, 40, 14, 8, 8, 8, 8], 1): st.column_dimensions[get_column_letter(j)].width = w

# ---- Verification register ----
vr = wb.create_sheet("Verification Register")
hdr(vr, 1, ["#", "Claim used in this kit", "Status", "Source", "Pre-delivery re-check"])
fills = {"Verified": "E2EFDA", "Version-sensitive": "FFF2CC", "Unverified": "FCE4D6", "Unverified (SAP coverage)": "FCE4D6", "Omitted by design": "EDEDED"}
for i, row in enumerate(VERIFY, 2):
    for j, v in enumerate(row, 1): vr.cell(row=i, column=j, value=v)
    vr.cell(row=i, column=3).fill = PatternFill("solid", fgColor=fills[row[2]])
for j, w in enumerate([6, 70, 22, 45, 60], 1): vr.column_dimensions[get_column_letter(j)].width = w

# ---- Prompt log template ----
pl = wb.create_sheet("Prompt Log")
cols = ["Date", "Analyst", "Prompt ID (or NEW)", "Surface", "Level used", "Prompt as run", "Output summary", "Verified against (cell)", "Verified? (Yes/No)", "What I changed in the prompt", "Keep in team playbook?"]
hdr(pl, 1, cols)
ex = ["2026-10-14", "Example analyst", "MOM-P10a", "Copilot in Excel (Chat only)", "L1", "What is total forecast gross sales for September 2026?",
      "Copilot said 104.6M", "Variance!H5 = 52.28M", "No", "Moved to MOM-P10b: excluded ProfitCenter = ALL", "Yes"]
for j, v in enumerate(ex, 1): pl.cell(row=2, column=j, value=v).font = Font(name=F, size=11, italic=True, color="7F7F7F")
for r_ in range(3, 53):
    for j in range(1, len(cols) + 1): pl.cell(row=r_, column=j).fill = PatternFill("solid", fgColor="FFF2CC")
dv = DataValidation(type="list", formula1='"Yes,No"', allow_blank=True); pl.add_data_validation(dv); dv.add("I3:I52"); dv.add("K3:K52")
dv2 = DataValidation(type="list", formula1='"L1,L2,L3,L4"', allow_blank=True); pl.add_data_validation(dv2); dv2.add("E3:E52")
pl["A54"] = "Row 2 is an example (grey italics). Yellow rows are for your entries."
for j, w in enumerate([12, 16, 14, 24, 9, 50, 34, 22, 12, 40, 14], 1): pl.column_dimensions[get_column_letter(j)].width = w

for wsx in wb.worksheets:
    for row in wsx.iter_rows():
        for cell in row:
            f0 = cell.font
            big = cell.coordinate == "A1" and wsx.title == "How to use"
            cell.font = Font(name=F, size=16 if big else 11, bold=f0.b, italic=f0.i, color=f0.color)
            cell.alignment = Alignment(wrap_text=True, vertical="top")
path = os.path.join(OUT, "Momentive_CRAFT_Prompt_Library.xlsx"); wb.save(path); print(path, len(LIB))
