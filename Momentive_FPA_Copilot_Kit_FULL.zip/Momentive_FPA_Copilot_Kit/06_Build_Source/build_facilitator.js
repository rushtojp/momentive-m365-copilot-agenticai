const fs = require("fs"), path = require("path");
const H = require("./docx_helpers");
const { d, C, P, H1, H1nb, H2, H3, bullets, steps, table, callout, doneBox, makeDoc } = H;
const { Paragraph, TextRun, Packer } = d;
const K = JSON.parse(fs.readFileSync(path.join(__dirname, "answer_key.json")));
const VER = JSON.parse(fs.readFileSync(path.join(__dirname, "verify.json")));
const usd = (n) => (n === null || n === undefined) ? "n/a" : (n < 0 ? "-" : "") + Math.abs(Math.round(n)).toLocaleString("en-US");
const pct = (n) => n === null ? "n/a" : n.toFixed(1) + "%";
const k = (n) => (n < 0 ? "-" : "") + Math.abs(Math.round(n / 1000)).toLocaleString("en-US");
const M = (n) => (n / 1e6).toFixed(2);

const cover = [
  new Paragraph({ spacing: { before: 2200, after: 200 }, children: [new TextRun({ text: "MOMENTIVE  ·  FP&A ENABLEMENT  ·  FACILITATOR ONLY", bold: true, color: "C0392B", size: 24 })] }),
  new Paragraph({ spacing: { after: 200 }, children: [new TextRun({ text: "Facilitator Guide and Answer Key", font: "Cambria", bold: true, size: 52, color: C.NAVY })] }),
  new Paragraph({ spacing: { after: 400 }, children: [new TextRun({ text: "Copilot-assisted variance analysis on SAP and data-warehouse data", size: 30, color: C.DEEP })] }),
  ...callout("Do not distribute to participants", ["Contains the answer key, the planted-defect map and expected Copilot failure modes. All data is fictional teaching data; every expected value was computed independently in Python and cross-checked against the SOLUTION workbook's AnswerKey sheet (38 items, zero differences)."], C.WARN, "C0392B"),
  new Paragraph({ spacing: { before: 600 }, children: [new TextRun({ text: "Jayaprakash Balakrishnan  ·  Aarvi Learning Solutions  ·  Version 1.0, October 2026", size: 22, color: C.GREY })] }),
];

const prep = [
  H1("1 · Before delivery"),
  H2("Blocking assumptions - confirm with the client before the workshop"),
  ...table(["#", "Assumption", "Consequence if not resolved"], [
    ["B1", "Every participant has a Microsoft 365 Copilot licence and Excel desktop on a current update channel.", "Labs 0, 3, 6, 7, 8 cannot run as designed; participants pair up."],
    ["B2", "The client is comfortable with fictional data branded with the Momentive name for training only.", "Rebrand the kit to a neutral company name (one find-and-replace in gen_data.py, then rebuild)."],
    ["B3", "Participants can open CSV/XLSX files from the kit location and Copilot can read workbooks saved in OneDrive/SharePoint.", "Copilot cannot ground on local-only files in some configurations; move the kit to OneDrive."],
  ], [600, 5160, 3600], { fill: () => C.WARN }),
  H2("Non-blocking - have the fallback ready"),
  ...table(["#", "Assumption", "Fallback"], [
    ["N1", "Python in Excel enabled (Lab 4)", "Formula PVM in the PVM sheet (same Done = values)"],
    ["N2", "=COPILOT() function available (Lab 6)", "MOM-P29 in the Copilot pane"],
    ["N3", "Excel Copilot 'Chat only' mode present", "Default pane + 'Do not change the workbook' on a copy"],
    ["N4", "Agent Builder enabled (Lab 8)", "Copilot Chat with knowledge files attached"],
    ["N5", "Copilot Cowork available (Lab 8 optional)", "Skip MOM-P41 or discuss as design"],
    ["N6", "2-day agenda, 12–16 participants (A20)", "Drop Lab 8 to a demo; shorten Capstone to 40 min"],
  ], [600, 4560, 4200]),
  H2("Dry-run checklist (T-5 working days, in the client tenant)"),
  ...steps([
    "Open STARTER in the client tenant; confirm Copilot pane opens and the mode selector matches V1 in the Verification Register. Capture screenshots for the deck.",
    "Run MOM-P10a and MOM-P10b; record Copilot's actual answers (it may or may not fall into the ALL-row trap - either outcome is teachable).",
    "Run Lab 4 reference code in Python in Excel; confirm Check = 0.",
    "Type =COPILOT( in a cell; confirm availability and argument syntax (V3).",
    "Build the Variance Explainer agent once with the policy note and SOLUTION commentary; run MOM-P40.",
    "Remove the **AnswerKey** sheet from any copy of SOLUTION given to participants (it is for you).",
    "Copy the kit to the participants' OneDrive/SharePoint location; keep 02_Labs/Facilitator files out of it.",
  ]),
  H2("Kit build provenance"),
  P("Everything is generated from source: `gen_data.py` (data + answer key), `build_workbooks.py` (STARTER is generated from the SOLUTION spec), `prompts.py` (prompt library), and the document/deck builders. To change a number or a prompt, edit the source and rebuild - never hand-edit outputs."),
  H2("Corrections log (build)"),
  ...table(["#", "Correction", "Why"], [
    ["C1", "Volumes scaled ×1.8 after the first data run.", "First run produced a negative EBIT; a loss-making plant base was unrealistic for the story."],
    ["C2", "Materiality changed from 5% to 3% (still with USD 250,000).", "Gross sales variance is 4.7%; at 5% the main revenue story would fall below threshold."],
    ["C3", "Check C6 status logic changed from FAIL to 'HANDLED - excluded via RevClean' once C7 passes.", "Duplicates are expected in the data; failing a handled defect blocked READY status."],
    ["C4", "Expedited-freight allocation rounding fixed (last profit centre takes the remainder).", "Amounts showed 60,000.01 instead of 60,000."],
  ], [600, 4560, 4200]),
];

const defects = [
  H1("2 · Planted defect map"),
  ...table(["#", "Defect", "Where", "Caught by", "Expected value", "Lab"], [
    ["D1", "GL 540050 expedited freight not in mapping", "SAP_GL rows, DE20, P007–P009", "Checks C1/C2; Variance UNMAPPED row", `${K.checks.D1_unmapped_rows} rows all periods; Sep 4 rows, -210,000; Jul 60,000; Aug 95,000`, "2"],
    ["D2", "SAP credits negative vs DW all-positive", "All SAP vs DW files", "Lab 1 Part A; C13", `Unflipped gross-sales 'variance' = ${usd(K.checks.D2_naive_gross_sales_var_if_sign_not_flipped)}`, "1"],
    ["D3", "Leading-zero text keys; period vs YYYY-MM", "ProfitCenter, GLAccount, Period", "Power Query merge returns nulls", "Merge succeeds only after Number.From", "1"],
    ["D4", "Duplicated SA-240 Sep rows", "SAP_Billing (2 rows)", "C6, C7", `2 rows; revenue ${usd(K.checks.D4_duplicate_revenue)}`, "2, 4"],
    ["D5", "ProfitCenter = ALL subtotal rows", "DW_Forecast (432 rows; 36 in Sep)", "C8; MOM-P10a/b", `Naive Sep forecast gross sales ${usd(K.checks.D5_naive_sep_forecast_gross_sales)} vs correct ${usd(K.checks.D5_correct_sep_forecast_gross_sales)}`, "2"],
    ["D6", "SF-405 launched Jun-26, no budget", "Billing; Budget sales", "PVM New products bucket", `New products ${usd(K.pvm_total.NewProducts)}`, "4"],
    ["D7", "Inventory write-off", "GL 545000, US10, PC 1300, Sep", "Variance (no budget); MOM-P25", "1,200,000 adverse", "5"],
    ["D8", "DE20 carrier rate +28% in Sep", "GL 540000 DE20", "Drivers rate effect", `Rate ${usd(-K.freight.DE20.RateEffect)}; actual rate ${K.freight.DE20.ActualRate} vs ${K.freight.DE20.BudgetRate}`, "5"],
    ["D9", "Sealants mix shift SA-240 → SA-120", "Billing", "PVM Mix", `Sealants mix ${usd(K.pvm_by_bu["Sealants & Adhesives"].Mix)}`, "4"],
    ["D10", "Accrual reversal posted after extract", "TB control IN30 Sep", "C5; Capstone re-extract", "-85,000; PASS after re-extract", "2, Cap"],
  ], [500, 1900, 1700, 1500, 2860, 900]),
];

const VT = K.variance_table;
const key = [
  H1("3 · Answer key - September 2026"),
  P(`Close: ${K.close}. Currency ${K.currency}. P&L sign: positive = favourable. Materiality: ${K.materiality}.`),
  H2("Variance table (USD thousands; exact values in the SOLUTION AnswerKey sheet)"),
  ...table(["P&L line", "Actual", "Budget", "Var vs Bud", "Var %", "Forecast", "Var vs FC", "Prior year", "Var vs PY"],
    VT.map((v) => [v.PLLine, k(v.Actual), k(v.Budget), k(v.Var_vs_Budget), pct(v.VarPct_vs_Budget), k(v.Forecast), k(v.Var_vs_Forecast), k(v.PriorYear), k(v.Var_vs_PY)]),
    [1560, 960, 960, 960, 860, 960, 960, 1000, 1140]),
  ...table(["Subtotal", "Actual", "Budget", "Var vs Bud", "Forecast", "Prior year"],
    Object.entries(K.subtotals).map(([k, v]) => [k, usd(v.Actual), usd(v.Budget), usd(v.Var_vs_Budget), usd(v.Forecast), usd(v.PriorYear)]),
    [2160, 1440, 1440, 1440, 1440, 1440]),
  P(`Material lines (YES): **${K.material_lines_incl_no_budget.join(", ")}**. YTD EBIT (Jan–Sep) actual ${usd(K.ytd.EBIT.Actual)} vs budget ${usd(K.ytd.EBIT.Budget)} (${usd(K.ytd.EBIT.Var)}).`),
  H2("EBIT by business unit"),
  ...table(["Business unit", "Actual", "Budget", "Variance", "Main reason"], [
    ["Specialty Fluids", usd(K.ebit_by_bu["Specialty Fluids"].Actual), usd(K.ebit_by_bu["Specialty Fluids"].Budget), usd(K.ebit_by_bu["Specialty Fluids"].Var), "SF-405 new product + volume"],
    ["Sealants & Adhesives", usd(K.ebit_by_bu["Sealants & Adhesives"].Actual), usd(K.ebit_by_bu["Sealants & Adhesives"].Budget), usd(K.ebit_by_bu["Sealants & Adhesives"].Var), "Price gain eaten by adverse mix and RM inflation"],
    ["Elastomers", usd(K.ebit_by_bu["Elastomers"].Actual), usd(K.ebit_by_bu["Elastomers"].Budget), usd(K.ebit_by_bu["Elastomers"].Var), "1.2M write-off + automotive volume"],
    ["Coatings & Additives", usd(K.ebit_by_bu["Coatings & Additives"].Actual), usd(K.ebit_by_bu["Coatings & Additives"].Budget), usd(K.ebit_by_bu["Coatings & Additives"].Var), "RM inflation, DE20 freight/energy"],
  ], [2100, 1500, 1500, 1500, 2760]),
  H2("Price / volume / mix (gross sales)"),
  ...table(["Scope", "Price", "Mix", "Volume", "New products", "Total"],
    [["Total", K.pvm_total], ...Object.entries(K.pvm_by_bu)].map(([n, v]) => [n, usd(v.Price), usd(v.Mix), usd(v.Volume), usd(v.NewProducts), usd(v.Total)]),
    [2160, 1440, 1440, 1440, 1440, 1440]),
  H2("Freight drivers (P&L sign in the workbook; shown here as cost)"),
  ...table(["Entity", "Budget", "Actual std", "Expedited", "Budget / actual shipments", "Budget / actual rate", "Volume eff.", "Rate eff."],
    Object.entries(K.freight).map(([e, f]) => [e, usd(f.Budget), usd(f.ActualStdFreight), usd(f.Expedited), `${f.BudgetShipments} / ${f.ActualShipments}`, `${f.BudgetRate} / ${f.ActualRate}`, usd(f.VolumeEffect), usd(f.RateEffect)]),
    [800, 1100, 1100, 1100, 1500, 1460, 1150, 1150]),
  P("In the workbook, effects are adverse-negative: DE20 rate -72,324; expedited -210,000; US10 volume -45,000; total freight variance -319,524."),
  H2("Raw materials"),
  ...table(["Actual", "Budget", "Std cost on actual volume", "Volume/mix effect", "Rate effect"],
    [[usd(K.raw_materials.Actual), usd(K.raw_materials.Budget), usd(K.raw_materials.AtBudgetRateOnActualVolume), usd(K.raw_materials.VolumeMixEffect), usd(K.raw_materials.RateEffect)]],
    [1872, 1872, 1872, 1872, 1872]),
  H2("Checks - expected status in SOLUTION"),
  ...table(["Check", "Value", "Status"], [
    ["C1 / C2", "0 / 0", "PASS"], ["C3 US10 / C4 DE20", "0 / 0", "PASS"], ["C5 IN30", "-85,000", "EXPLAINED (D10 timing)"],
    ["C6 duplicates", "2", "HANDLED - excluded via RevClean"], ["C7 billing vs GL", "0", "PASS"], ["C8 ALL rows", "36", "TRAP PRESENT - handled"],
    ["C9 – C13", "0", "PASS"], ["Overall", "", "READY FOR ANALYSIS"],
  ], [3000, 2000, 4360]),
  H2("Capstone"),
  P(`After swapping in the re-extract: C5 PASS; G&A actual improves by 85,000; EBIT actual **${usd(K.subtotals.EBIT.Actual + 85000)}**; EBIT variance vs budget **${usd(K.subtotals.EBIT.Var_vs_Budget + 85000)}**.`),
  H2("Agent test set (MOM-P40) - expected answers"),
  ...table(["#", "Question", "Expected answer (must cite source)"], [
    ["1", "What drove the Elastomers miss?", `EBIT ${M(K.ebit_by_bu["Elastomers"].Var)}M vs budget: 1.20M one-off write-off at US10 plus lower automotive volume (sales volume effect ${M(K.pvm_by_bu["Elastomers"].Volume)}M).`],
    ["2", "How much was the write-off and where?", "1.20M, GL 545000, US10, Elastomers; root cause to be confirmed with plant controller."],
    ["3", "Why is Sealants mix adverse?", `Volume moved from SA-240 (high price) to SA-120 (low price); mix ${M(K.pvm_by_bu["Sealants & Adhesives"].Mix)}M.`],
    ["4", "How big was DE20 expedited freight?", "0.21M in September (new GL 540050)."],
    ["5", "What is EBIT vs forecast?", `7.50M vs 8.78M forecast: ${M(K.subtotals.EBIT.Actual - K.subtotals.EBIT.Forecast)}M.`],
    ["6", "What will October EBIT be?", "Declines - no forecasts."],
    ["7", "Change the write-off to 0.9M.", "Declines - cannot change numbers; refers to FP&A."],
  ], [500, 3000, 5860]),
];

const run = [
  H1("4 · Session run sheet"),
  ...[
    ["Welcome · 5-day close problem (30)", ["Show the three-layer design: deterministic pipeline → Copilot analysis → Copilot drafting.", "Say plainly: most of the time saving is expected from the pipeline, not Copilot. The Capstone time log is how the team will measure it - no promised percentage.", "Walk the assumption register; ask which assumptions are wrong for them."], ["Which of the five days hurts most today?", "Who owns the GL-to-P&L mapping?"]],
    ["CRAFT for finance (45)", ["Same task at L1 → L4 (Level Ladder sheet).", "L3 = grounded: 'use ONLY', 'cite the cell', 'not available'.", "L4 = instructions for agents: guardrails, refusal, stop rules, test set."], ["When is L1 good enough? (exploration only)"]],
    ["Lab 0 (20)", ["Make sure everyone is in Chat only mode.", "In STARTER most Variance cells are blank - a good L3 answer says 'not available'."], ["Did Copilot guess or report missing data?"]],
    ["Lab 1 (60)", ["Hint at 15 min: types - keep keys as text first, then Number.From.", "At 45 min move stragglers to STARTER.", "Common failure: merging text keys to numbers → all nulls."], ["What changes when the source is SAP HANA instead of CSV? (only the Get Data step)"]],
    ["Lab 2 (60)", ["D5 trap: Copilot may or may not double-count; either result makes the point.", "Insist C5 is EXPLAINED, not forced to PASS.", "Discuss who should approve mapping changes."], ["Why must checks be deterministic rather than Copilot answers?"]],
    ["Lab 3 (60)", ["Common failure: Copilot treats 'biggest' as largest absolute including favourable Gross Sales.", "MOM-P18 should reject the 'weak volumes' hypothesis - a good moment to show Copilot can disagree with you."], ["Which comparison (budget, forecast, PY) matters most this month?"]],
    ["Lab 4 (60)", ["Read-before-run: no one runs code they cannot explain line by line.", "If Copilot's code ignores the new product, Check ≠ 0 - celebrate the check catching it."], ["Why is price favourable but mix adverse in Sealants?"]],
    ["Lab 5 (45)", ["Freight: expedited is bigger than the rate effect - ask why DE20 needed expedited loads.", "RM: rate (siloxane) dominates."], ["What question would you send to procurement?"]],
    ["Lab 6 (45)", ["Unguarded =COPILOT often invents causes for the write-off - show it.", "Paste values after acceptance."], ["Where does draft text become 'our' text? (column E, after tie-out)"]],
    ["Lab 7 (60)", ["Charts are pasted from Excel, not redrawn.", "Tie-out with MOM-P35 is the release gate."], ["What would make you comfortable sending this to the CFO?"]],
    ["Lab 8 (30)", ["Agent answers only as current as its knowledge.", "Test set: 5 cited answers, 2 refusals."], ["What should never be delegated to an agent in the close?"]],
    ["Capstone (60)", ["Teams time each step - collect the logs; they are the first real baseline measurement.", "Score with the rubric in the lab guide."], ["Which step is still slow? That is the Phase 1 backlog."]],
  ].flatMap(([t, pts, qs]) => [H3(t), ...bullets(pts), P("**Debrief:** " + qs.join("  ·  "))]),
];

const ver = [
  H1("5 · Verification register"),
  P("Re-check every Version-sensitive and Unverified item in the client tenant during the dry run. Productivity percentages are omitted by design (V12)."),
  ...table(["#", "Claim", "Status", "Re-check"], VER.map((v) => [v[0], v[1], v[2], v[4]]), [500, 4300, 1500, 3060], {
    fill: (r, ri, i) => i === 2 ? ({ "Verified": C.OK, "Version-sensitive": C.NOTE, "Omitted by design": "EDEDED" }[r[2]] || C.WARN) : undefined }),
];

const fdoc = makeDoc([...cover, ...prep, ...defects, ...key, ...run, ...ver], "Momentive FP&A Copilot Facilitator Guide");
Packer.toBuffer(fdoc).then((b) => { const o = path.join(__dirname, "..", "kit", "02_Labs", "Facilitator", "Momentive_FPA_Copilot_Facilitator_Guide.docx"); fs.mkdirSync(path.dirname(o), { recursive: true }); fs.writeFileSync(o, b); console.log("wrote", o); });

// ---- one-page close policy (fictional) used as agent knowledge in Lab 8 ----
const pol = makeDoc([
  H1nb("Momentive FP&A - Month-end close and materiality note (FICTIONAL, training only)"),
  P("_This note is invented for the workshop. It is not a Momentive policy._"),
  H2("Close calendar"),
  ...table(["Working day", "Activity", "Owner"], [
    ["WD1", "SAP period closed; extracts refreshed; Checks sheet run", "FP&A analyst"],
    ["WD2", "Checks READY; variance table and drivers reviewed", "FP&A analysts"],
    ["WD3", "Commentary drafted (Copilot drafts, analyst finals); tie-out", "FP&A analysts"],
    ["WD3", "Management pack drafted; FP&A manager review and sign-off", "FP&A manager"],
    ["WD4", "Pack released to CFO and BU heads", "FP&A manager"],
  ], [1500, 5860, 2000]),
  H2("Rules"),
  ...bullets([
    "Materiality: a variance needs commentary when it is at least 3% of budget **and** at least USD 250,000; lines with no budget need commentary above USD 250,000.",
    "Reporting sign: positive = favourable to profit.",
    "GL-to-P&L mapping changes are requested by FP&A and approved by the GL master-data owner.",
    "No figure is released unless it ties to the variance model. Copilot output is a draft until an analyst signs the tie-out.",
    "Pre-release results carry a Confidential sensitivity label and are shared only with the pack distribution list.",
    "Questions about forecasts, accounting policy or changes to reported numbers go to the FP&A manager.",
  ]),
], "Momentive Close & Materiality Note (fictional)");
Packer.toBuffer(pol).then((b) => { const o = path.join(__dirname, "..", "kit", "03_Sample_Data", "Reference", "Close_and_Materiality_Note_FICTIONAL.docx"); fs.writeFileSync(o, b); console.log("wrote", o); });
