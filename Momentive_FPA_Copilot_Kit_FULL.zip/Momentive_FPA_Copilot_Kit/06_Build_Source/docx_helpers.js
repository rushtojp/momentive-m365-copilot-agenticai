const d = require("docx");
const { Paragraph, TextRun, Table, TableRow, TableCell, WidthType, ShadingType, AlignmentType, BorderStyle,
  HeadingLevel, LevelFormat, Footer, Header, PageNumber, TableLayoutType } = d;

const C = { NAVY: "21295C", DEEP: "065A82", TEAL: "1C7293", MINT: "16A0A0", GOLD: "E0A800", GREY: "595959",
  LIGHT: "EAF2F8", WARN: "FCE4D6", OK: "E2EFDA", NOTE: "FFF2CC" };
const FULL = 9360; // US Letter, 1" margins
let listCounter = 0;
const numberingConfigs = [];

function runs(text, base = {}) {
  // **bold**, `code`, _italic_
  const out = []; const re = /(\*\*[^*]+\*\*|`[^`]+`|(?<![A-Za-z0-9])_[^_]+_(?![A-Za-z0-9]))/g; let last = 0, m;
  const s = String(text);
  while ((m = re.exec(s))) {
    if (m.index > last) out.push(new TextRun({ text: s.slice(last, m.index), ...base }));
    const t = m[0];
    if (t.startsWith("**")) out.push(new TextRun({ text: t.slice(2, -2), bold: true, ...base }));
    else if (t.startsWith("`")) out.push(new TextRun({ text: t.slice(1, -1), font: "Consolas", size: 19, color: C.DEEP, ...base }));
    else out.push(new TextRun({ text: t.slice(1, -1), italics: true, ...base }));
    last = m.index + t.length;
  }
  if (last < s.length) out.push(new TextRun({ text: s.slice(last), ...base }));
  return out;
}
const P = (text, opts = {}) => new Paragraph({ children: runs(text, opts.run || {}), spacing: { after: 120, line: 276 }, ...opts.para });
const H1 = (t) => new Paragraph({ heading: HeadingLevel.HEADING_1, children: [new TextRun(t)], pageBreakBefore: true, spacing: { after: 160 } });
const H1nb = (t) => new Paragraph({ heading: HeadingLevel.HEADING_1, children: [new TextRun(t)], spacing: { after: 160 } });
const H2 = (t) => new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun(t)], spacing: { before: 240, after: 120 } });
const H3 = (t) => new Paragraph({ heading: HeadingLevel.HEADING_3, children: [new TextRun(t)], spacing: { before: 180, after: 80 } });

function newList(kind) {
  const ref = `${kind}-${++listCounter}`;
  numberingConfigs.push({ reference: ref, levels: [{ level: 0, format: kind === "num" ? LevelFormat.DECIMAL : LevelFormat.BULLET,
    text: kind === "num" ? "%1." : "•", alignment: AlignmentType.LEFT,
    style: { paragraph: { indent: { left: 540, hanging: 300 } } } }] });
  return ref;
}
const bullets = (items) => { const ref = newList("bul"); return items.map((t) => new Paragraph({ numbering: { reference: ref, level: 0 }, children: runs(t), spacing: { after: 60 } })); };
const steps = (items) => { const ref = newList("num"); return items.map((t) => new Paragraph({ numbering: { reference: ref, level: 0 }, children: runs(t), spacing: { after: 80 } })); };

const border = { style: BorderStyle.SINGLE, size: 4, color: "BFBFBF" };
const borders = { top: border, bottom: border, left: border, right: border };
function table(headers, rows, widths, opts = {}) {
  const total = widths.reduce((a, b) => a + b, 0);
  const mk = (txt, w, hdr, fill) => new TableCell({ width: { size: w, type: WidthType.DXA }, borders,
    shading: hdr ? { fill: C.NAVY, type: ShadingType.CLEAR, color: "auto" } : (fill ? { fill, type: ShadingType.CLEAR, color: "auto" } : undefined),
    margins: { top: 60, bottom: 60, left: 100, right: 100 },
    children: String(txt).split("\n").map((line) => new Paragraph({ children: runs(line, hdr ? { bold: true, color: "FFFFFF", size: 19 } : { size: 19 }),
      alignment: (!hdr && opts.right && opts.right.includes(widths.indexOf(w)) ) ? AlignmentType.RIGHT : AlignmentType.LEFT })) });
  const out = [];
  out.push(new TableRow({ tableHeader: true, children: headers.map((h, i) => mk(h, widths[i], true)) }));
  rows.forEach((r, ri) => out.push(new TableRow({ children: r.map((c, i) => mk(c, widths[i], false, opts.fill ? opts.fill(r, ri, i) : undefined)) })));
  return [new Table({ width: { size: total, type: WidthType.DXA }, columnWidths: widths, rows: out, layout: TableLayoutType.FIXED }), new Paragraph({ children: [], spacing: { after: 80 } })];
}
function callout(title, lines, fill = C.LIGHT, accent = C.TEAL) {
  const body = (Array.isArray(lines) ? lines : [lines]).map((l) => new Paragraph({ children: runs(l, { size: 20 }), spacing: { after: 60 } }));
  return [new Table({ width: { size: FULL, type: WidthType.DXA }, columnWidths: [FULL], layout: TableLayoutType.FIXED, rows: [new TableRow({ children: [new TableCell({
    width: { size: FULL, type: WidthType.DXA }, shading: { fill, type: ShadingType.CLEAR, color: "auto" },
    borders: { top: { style: BorderStyle.SINGLE, size: 4, color: fill }, bottom: { style: BorderStyle.SINGLE, size: 4, color: fill }, right: { style: BorderStyle.SINGLE, size: 4, color: fill }, left: { style: BorderStyle.SINGLE, size: 24, color: accent } },
    margins: { top: 100, bottom: 100, left: 180, right: 140 },
    children: [new Paragraph({ children: [new TextRun({ text: title, bold: true, color: accent, size: 21 })], spacing: { after: 80 } }), ...body] })] })] }),
    new Paragraph({ children: [], spacing: { after: 100 } })];
}
function code(lines) {
  const arr = Array.isArray(lines) ? lines : String(lines).split("\n");
  return [new Table({ width: { size: FULL, type: WidthType.DXA }, columnWidths: [FULL], layout: TableLayoutType.FIXED, rows: [new TableRow({ children: [new TableCell({
    width: { size: FULL, type: WidthType.DXA }, shading: { fill: "F3F4F6", type: ShadingType.CLEAR, color: "auto" }, borders,
    margins: { top: 80, bottom: 80, left: 140, right: 140 },
    children: arr.map((l) => new Paragraph({ children: [new TextRun({ text: l.length ? l : " ", font: "Consolas", size: 17 })], spacing: { after: 0, line: 240 } })) })] })] }),
    new Paragraph({ children: [], spacing: { after: 100 } })];
}
function prompt(p) {
  const parts = [["Context", p.C], ["Role", p.R], ["Action", p.A], ["Format", p.F], ["Target & tone", p.T]].filter((x) => x[1]);
  const isFormula = p.Surface.startsWith("=COPILOT") || p.ID === "MOM-P40";
  const lines = isFormula ? [p.A] : parts.map(([k, v]) => `${k}: ${v}`);
  return [
    new Paragraph({ children: [new TextRun({ text: `${p.ID}  ·  ${p.Level}  ·  ${p.Surface}`, bold: true, color: C.TEAL, size: 19 })], spacing: { before: 120, after: 40 } }),
    ...code(lines),
    new Paragraph({ children: runs(`**Expected:** ${p.Expected}`, { size: 19 }), spacing: { after: 40 } }),
    new Paragraph({ children: runs(`**Verify against:** ${p.Verify}`, { size: 19 }), spacing: { after: 120 } }),
  ];
}
const doneBox = (lines) => callout("Done =", lines, C.OK, "2E7D32");
const verifyBox = (lines) => callout("Verify before you trust it", lines, C.NOTE, "B7791F");
const pb = () => new Paragraph({ pageBreakBefore: true, children: [] });

function makeDoc(sections, titleText) {
  return new d.Document({
    creator: "Jayaprakash Balakrishnan", title: titleText,
    styles: {
      default: { document: { run: { font: "Calibri", size: 21 } } },
      paragraphStyles: [
        { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true, run: { size: 34, bold: true, font: "Cambria", color: C.NAVY }, paragraph: { spacing: { before: 240, after: 160 }, outlineLevel: 0 } },
        { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true, run: { size: 27, bold: true, font: "Cambria", color: C.DEEP }, paragraph: { spacing: { before: 220, after: 120 }, outlineLevel: 1 } },
        { id: "Heading3", name: "Heading 3", basedOn: "Normal", next: "Normal", quickFormat: true, run: { size: 23, bold: true, font: "Cambria", color: C.TEAL }, paragraph: { spacing: { before: 160, after: 80 }, outlineLevel: 2 } },
      ] },
    numbering: { config: numberingConfigs },
    sections: [{ properties: { page: { size: { width: 12240, height: 15840 }, margin: { top: 1440, right: 1440, bottom: 1300, left: 1440 } } },
      headers: { default: new Header({ children: [new Paragraph({ alignment: AlignmentType.RIGHT, children: [new TextRun({ text: titleText + "  ·  Fictional teaching data", size: 16, color: C.GREY })] })] }) },
      footers: { default: new Footer({ children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: "Aarvi Learning Solutions  ·  Page ", size: 16, color: C.GREY }), new TextRun({ children: [PageNumber.CURRENT], size: 16, color: C.GREY })] })] }) },
      children: sections }],
  });
}
module.exports = { d, C, FULL, runs, P, H1, H1nb, H2, H3, bullets, steps, table, callout, code, prompt, doneBox, verifyBox, pb, makeDoc };
