const fs = require("fs"), path = require("path");
const H = require("./docx_helpers");
const { d, C, P, H1, H1nb, H2, H3, bullets, steps, table, callout, code, prompt, doneBox, verifyBox, makeDoc } = H;
const { Paragraph, TextRun, AlignmentType, Packer } = d;
const K = JSON.parse(fs.readFileSync(path.join(__dirname, "answer_key.json")));
const PR = JSON.parse(fs.readFileSync(path.join(__dirname, "prompts.json")));
const byId = Object.fromEntries(PR.LIB.map((p) => [p.ID, p]));
const pr = (id) => prompt(byId[id]);
const usd = (n) => (n < 0 ? "-" : "") + Math.abs(Math.round(n)).toLocaleString("en-US");
const usd2 = (n) => (n < 0 ? "-" : "") + Math.abs(n).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const m = (n) => (n < 0 ? "-" : "+") + (Math.abs(n) / 1e6).toFixed(2) + "M";
const VT = Object.fromEntries(K.variance_table.map((v) => [v.PLLine, v]));
const PYCODE = fs.readFileSync(path.join(__dirname, "..", "kit", "02_Labs", "code", "lab4_pvm_python_in_excel.py"), "utf8");

const cover = [
  new Paragraph({ spacing: { before: 2200, after: 200 }, children: [new TextRun({ text: "MOMENTIVE  ·  FP&A ENABLEMENT", bold: true, color: C.TEAL, size: 24 })] }),
  new Paragraph({ spacing: { after: 200 }, children: [new TextRun({ text: "Copilot-assisted variance analysis on SAP and data-warehouse data", font: "Cambria", bold: true, size: 52, color: C.NAVY })] }),
  new Paragraph({ spacing: { after: 400 }, children: [new TextRun({ text: "Participant Lab Guide  ·  Labs 0–8 and Capstone", size: 30, color: C.DEEP })] }),
  ...callout("About the data", [
    "Every company code, plant, product, customer segment and figure in this guide is **fictional teaching data** built for this workshop. It is shaped like a silicones manufacturer's month-end close but is **not Momentive data** and must not be quoted as such.",
    "Copilot features change frequently. Items marked **[VERIFY]** are version-sensitive and are listed in the Verification Register in the Prompt Library workbook.",
  ], C.NOTE, "B7791F"),
  new Paragraph({ spacing: { before: 600 }, children: [new TextRun({ text: "Prepared by Jayaprakash Balakrishnan  ·  Aarvi Learning Solutions", size: 22, color: C.GREY })] }),
  new Paragraph({ children: [new TextRun({ text: "Version 1.0  ·  October 2026  ·  Close month in all labs: September 2026 (FY2026 P009)", size: 22, color: C.GREY })] }),
];

const intro = [
  H1("How to use this guide"),
  P("This workshop rebuilds a month-end variance cycle that today takes about five working days: extract from SAP and the data warehouse, reconcile, calculate variances, explain the drivers and write the management pack. You will build each stage yourself, with Microsoft 365 Copilot doing the explaining and drafting and Excel (Power Query, formulas, Python) doing the arithmetic."),
  ...callout("The golden rule of this workshop", [
    "**Copilot explains and drafts. Power Query, formulas and Python produce the numbers.** Every figure Copilot gives you is tied to a cell before it goes anywhere. Each lab ends with a **Done =** check that you can verify yourself.",
  ]),
  H2("Conventions"),
  ...table(["Marker", "Meaning"], [
    ["**MOM-Pxx**", "A prompt from the CRAFT Prompt Library workbook. The full text is printed in the lab; copy it from the workbook to avoid typos."],
    ["**L1 – L4**", "CRAFT level. L1 = Action + Format. L2 = + Role, Context. L3 = all five elements, grounded on named sheets with 'use ONLY' and 'not available'. L4 = reusable agent instructions with guardrails."],
    ["**Done =**", "Binary acceptance check. If it is not met, the lab is not finished."],
    ["**Dn**", "A planted defect in the data (D1–D10). Finding them is part of the work, exactly as in a real close."],
    ["**[VERIFY]**", "Version-sensitive Copilot behaviour. If your screen differs, use the fallback in Appendix D."],
    ["**Chat only**", "Copilot in Excel mode that answers without editing the workbook. Use it on the controlled model. Edits only on a working copy. [VERIFY]"],
  ], [1700, 7660]),
  H2("Agenda (two days)"),
  P("_Assumption A20: 2-day instructor-led workshop for 12–16 FP&A analysts with Microsoft 365 Copilot licences. Your facilitator may adjust timings._"),
  ...table(["Day", "Time", "Session", "Lab", "Mins"], [
    ["1", "09:30", "Welcome · the 5-day close problem · target design", "", "30"],
    ["1", "10:00", "CRAFT for finance: the L1 → L4 ladder", "", "45"],
    ["1", "11:00", "Orientation and CRAFT warm-up", "Lab 0", "20"],
    ["1", "11:20", "Ingest SAP and DW extracts with Power Query", "Lab 1", "60"],
    ["1", "13:05", "Reconcile: build the Checks sheet", "Lab 2", "60"],
    ["1", "14:20", "Variance table and grounded Copilot exploration", "Lab 3", "60"],
    ["1", "15:20", "Day 1 review", "", "25"],
    ["2", "09:45", "Price / volume / mix with Python in Excel", "Lab 4", "60"],
    ["2", "11:00", "Cost drivers: freight, raw materials, one-offs", "Lab 5", "45"],
    ["2", "11:45", "Commentary: =COPILOT() drafts, analyst finals", "Lab 6", "45"],
    ["2", "13:15", "Management pack in Word, PowerPoint, Outlook", "Lab 7", "60"],
    ["2", "14:30", "Agents: Variance Explainer and close gatekeeper", "Lab 8", "30"],
    ["2", "15:00", "Capstone: timed refresh-to-pack run", "Capstone", "60"],
    ["2", "16:00", "Debrief and rollout plan", "", "30"],
  ], [600, 900, 5100, 1360, 1400]),
  H2("What you need"),
  ...table(["Item", "Why", "Fallback if missing"], [
    ["Excel for Microsoft 365 desktop, current channel", "Power Query, Copilot pane, Python in Excel, =COPILOT()", "Facilitator demo; STARTER workbook skips Power Query"],
    ["Microsoft 365 Copilot licence", "Copilot in Excel, Word, PowerPoint, Outlook; Agent Builder", "Pair with a licensed colleague"],
    ["Python in Excel enabled [VERIFY]", "Lab 4", "Formula version of PVM already in the PVM sheet structure"],
    ["Lab kit folder (see below)", "All data and workbooks", "Facilitator USB / SharePoint copy"],
  ], [3000, 3400, 2960]),
  H2("Lab kit contents"),
  ...table(["Folder / file", "What it is"], [
    ["03_Sample_Data/SAP_Extracts/SAP_GL_Actuals_FY2025_FY2026.csv", "SAP GL line totals by company, profit centre, cost centre, GL account, period. 4,633 rows. SAP sign (credits negative). Keys are text with leading zeros."],
    ["SAP_Billing_Sales_FY2025_FY2026.csv", "Billing quantities (MT) and revenue by material and customer segment. 514 rows (contains a planted duplicate block)."],
    ["SAP_TrialBalance_Control.csv", "SAP P&L control total per company and period - the reconciliation anchor."],
    ["SAP_Material_StdCost.csv", "Standard raw-material cost per MT by material (material master)."],
    ["SAP_GL_Actuals_Sep2026_REEXTRACT.csv", "September GL re-extract taken later - used in the Capstone."],
    ["03_Sample_Data/DW_Extracts/DW_Budget_PL_FY2026.csv", "Budget by entity, profit centre, P&L line, month. All values positive; LineType says Revenue or Cost."],
    ["DW_Budget_Sales_FY2026.csv", "Budget quantity, revenue and price by material and segment."],
    ["DW_Forecast_6plus6_FY2026.csv", "6+6 forecast by P&L line (contains planted subtotal rows)."],
    ["DW_Ops_Volumes_FY2026.csv", "Shipped MT, shipments, production, headcount - actual and budget."],
    ["03_Sample_Data/Reference/GL_to_PL_Mapping.csv", "GL account → P&L line mapping maintained by FP&A."],
    ["04_Workbooks/Momentive_Variance_Model_STARTER.xlsx", "All data loaded as Excel Tables with helper columns; yellow cells for you to complete. Use it if Lab 1 is not finished or from Lab 2 onwards."],
    ["05_Prompt_Library/Momentive_CRAFT_Prompt_Library.xlsx", "46 CRAFT prompts, level ladder, anti-patterns, Verification Register, Prompt Log."],
    ["02_Labs/code/lab4_pvm_python_in_excel.py", "Reference Python for Lab 4."],
  ], [4200, 5160]),
];

const scenario = [
  H1("The scenario"),
  P("Momentive's FP&A team compares SAP actuals with budget, forecast and operational data held in the enterprise data warehouse to explain P&L line items, sales variance and cost drivers each month. The current cycle takes about five working days. The goal stated by the business is to cut it by at least half."),
  H2("The fictional business in the data"),
  ...table(["Company code", "Name (fictional)", "Products sold"], [
    ["US10", K.companies.US10, "SF-101, SF-405 (new), SA-120, SA-360, EL-150, CA-220"],
    ["DE20", K.companies.DE20, "SF-205, SA-240, EL-250, CA-110"],
    ["IN30", K.companies.IN30, "SF-310, EL-350, CA-330"],
  ], [1600, 3600, 4160]),
  ...table(["Profit centre", "Business unit", "Story this month (what you should discover)"], [
    ["1100", "Specialty Fluids", "New Low-VOC fluid SF-405 launched June with no budget; volumes up."],
    ["1200", "Sealants & Adhesives", "List-price increase, but volume shifted to the cheaper construction sealant."],
    ["1300", "Elastomers", "Automotive volumes down; a large one-off at the US plant."],
    ["1400", "Coatings & Additives", "Close to budget on sales; cost inflation erodes margin."],
  ], [1600, 2400, 5360]),
  H2("Where the data comes from"),
  P("In production the SAP data would arrive through Power Query's SAP HANA or SAP BW connectors (which need the SAP HANA ODBC driver or SAP .NET Connector on each machine) and the DW data through its database connector. In class, CSV extracts stand in for those connections so everyone has the same data. The Power Query steps after **Get Data** are the same either way."),
  ...callout("Key assumptions behind this design (full register in Appendix E)", [
    "A1 SAP S/4HANA and A2 SAP BW hold actuals · A3 'warehouse' = enterprise data warehouse holding budget, forecast and volumes · A5 single reporting currency (USD) · A16 materiality = |variance| ≥ 3% **and** ≥ USD 250,000 · A19 the five days split roughly 1.0 extract / 1.5 reconcile / 0.5 calculate / 1.0 investigate / 1.0 write-up.",
    "If the client's reality differs, the lab steps still apply; only the connector and thresholds change.",
  ]),
  H2("The CRAFT framework"),
  ...table(["Letter", "Element", "Finance example"], [
    ["C", "Context", "Sep 2026 close, USD, P&L sign positive = favourable; sheets Variance, Drivers; tbl_gl is SAP"],
    ["R", "Role", "You are a senior FP&A analyst reviewing a month-end pack"],
    ["A", "Action", "ONE verb: identify / explain / draft / compare / reconcile"],
    ["F", "Format", "Table: P&L line | Var | Var % | Source cell"],
    ["T", "Target & tone", "For the FP&A manager; neutral; use ONLY the named sheets; say 'not available' if missing"],
  ], [900, 1800, 6660]),
];

function labHeader(n, title, mins, goal, prompts) {
  return [H1(`${n} · ${title}`), ...table(["Time", "Goal", "Prompts used"], [[`${mins} min`, goal, prompts]], [1100, 5560, 2700])];
}

const lab0 = [
  ...labHeader("Lab 0", "Orientation and CRAFT warm-up", 20, "Find your way around the model and feel the difference between an L1 and an L3 prompt on the same question.", "MOM-P12, MOM-P14"),
  H2("Steps"),
  ...steps([
    "Open `Momentive_Variance_Model_STARTER.xlsx`. Read the **README** sheet. Note the sign convention: positive = favourable to profit.",
    "Click through **Inputs** (close year 2026, period 9), **Checks**, **Variance**, **PVM**, **Drivers**, **Commentary** and the data sheets. Every data sheet is an Excel Table named `tbl_…`.",
    "Open Copilot in Excel and select **Chat only** mode. [VERIFY: mode names in your build]",
    "Run the L1 prompt below. Write down what Copilot returns.",
    "Run the L3 prompt below in a new chat. Compare the two answers in the **Prompt Log** sheet of the Prompt Library.",
  ]),
  ...pr("MOM-P12"),
  ...pr("MOM-P14"),
  P("_In the STARTER file most Variance cells are empty, so the L3 answer should say figures are 'not available' for those lines. That is the point: an L3 prompt reports what is missing instead of guessing. You will fill those cells in Lab 3._"),
  ...doneBox(["Two rows in your Prompt Log (MOM-P12, MOM-P14) with the **Verified?** column filled.", "You can explain in one sentence why the L3 answer is safer than the L1 answer."]),
];

const lab1 = [
  ...labHeader("Lab 1", "Ingest SAP and DW extracts with Power Query", 60, "Build repeatable queries that load SAP GL and DW budget/forecast, align keys and signs, and map GL accounts to P&L lines. This step replaces most of 'Day 1' of today's close.", "MOM-P02, MOM-P03, MOM-P04"),
  H2("Part A - ask Copilot what will break (10 min)"),
  P("Before touching Power Query, open the two CSVs in Excel (or the STARTER data sheets) and ask Copilot what will stop them joining."),
  ...pr("MOM-P02"),
  ...verifyBox(["Copilot should name at least: text keys with leading zeros (**D3**), period '009' vs month '2026-09', and the sign convention (**D2**). If it misses the sign convention, ask MOM-P04 next."]),
  ...pr("MOM-P04"),
  H2("Part B - build the queries (40 min)"),
  P("Work in a new blank workbook named `Momentive_Close_PQ.xlsx`."),
  H3("Query 1: SAP GL"),
  ...steps([
    "**Data → Get Data → From File → From Text/CSV** → `SAP_GL_Actuals_FY2025_FY2026.csv` → **Transform Data**.",
    "Rename the query `q_gl`. Leave `ProfitCenter`, `GLAccount` and `Period` as **Text** for now so leading zeros are visible.",
    "**Add Column → Custom Column** `GL6` = `Number.From([GLAccount])`; `PCnum` = `Number.From([ProfitCenter])`; `PeriodNum` = `Number.From([Period])`. Set all three to **Whole Number**.",
    "**Add Column → Custom Column** `PLAmount` = `-[AmountUSD]`. Set to **Decimal Number**. (SAP credits are negative; we report favourable = positive.)",
  ]),
  H3("Query 2: mapping"),
  ...steps([
    "**Get Data → From Text/CSV** → `GL_to_PL_Mapping.csv`; name it `q_map`; set `GLAccount` to **Whole Number**.",
    "Back in `q_gl`: **Home → Merge Queries** → match `q_gl[GL6]` to `q_map[GLAccount]`, **Left Outer**. Expand only `PLLine` and `PLSection`.",
    "**Transform → Replace Values** in `PLLine`: replace `null` with `UNMAPPED`. Never let unmapped rows disappear silently.",
  ]),
  H3("Query 3 and 4: DW budget and forecast"),
  ...steps([
    "Load `DW_Budget_PL_FY2026.csv` as `q_budget`. Add `Year` = `Number.From(Text.Start([Month],4))`, `PeriodNum` = `Number.From(Text.End([Month],2))`.",
    "**Add Column → Conditional Column** `PLAmount`: if `LineType` equals `Revenue` then `[BudgetUSD]` else `-[BudgetUSD]` (use a Custom Column `if [LineType] = \"Revenue\" then [BudgetUSD] else -[BudgetUSD]`).",
    "Repeat for `DW_Forecast_6plus6_FY2026.csv` as `q_forecast` with `ForecastUSD`. **Do not filter anything yet** - you will find a trap in Lab 2.",
    "**Close & Load To… → Table** for `q_gl`, `q_budget`, `q_forecast`. Load `q_map` as a table too (you will edit it).",
  ]),
  P("Ask Copilot for help on any step you are unsure of:"),
  ...pr("MOM-P03"),
  ...callout("Production note", ["Replace **From Text/CSV** with **From Database → From SAP HANA Database** (or the SAP BW connector) once IT has installed the drivers and granted a read-only account. Every later step stays the same, so each month becomes **Data → Refresh All**."]),
  H2("Part C - control totals (10 min)"),
  P("Add a small PivotTable or SUMIFS block and confirm the numbers below. If they do not match, fix the query - do not adjust the numbers."),
  ...doneBox([
    "`q_gl` loads **4,633** rows; `q_budget` **1,584**; `q_forecast` **2,028**.",
    `Sum of \`PLAmount\` in \`q_gl\` for FiscalYear 2026, PeriodNum 9 = **${usd2(K.checks.sep_gl_total_net_income)}**.`,
    "Exactly **4** rows in September 2026 have `PLLine` = `UNMAPPED`, totalling **-210,000** (you will resolve them in Lab 2).",
    "If you cannot reach these numbers in 60 minutes, switch to the STARTER workbook - it contains the same tables.",
  ]),
];

const lab2 = [
  ...labHeader("Lab 2", "Reconcile: build the Checks sheet", 60, "Make the model prove it is complete and consistent before anyone analyses it. Each check maps to a planted defect.", "MOM-P06 – P10b, MOM-P07"),
  P("Open the STARTER workbook (or your Lab 1 workbook with the same tables). Go to **Checks**. Row C1 is complete as a worked example; complete C2 – C8 using the same pattern. C9 – C13 are finished in Labs 4 – 5."),
  H2("Task 1 - unmapped GL accounts (D1)"),
  ...pr("MOM-P06"),
  ...steps([
    "Confirm Copilot's answer with a filter on `tbl_gl[PLLine]` = `UNMAPPED`.",
    "Draft the question to the GL owner with MOM-P07 below (do **not** send it).",
    "For class purposes the owner replies: _'540050 is outbound freight - expedited loads. Map it to Freight Outbound.'_ Add a row to the **map** sheet: `540050 | Freight Outbound | Cost of Sales | 7 | Cost`.",
    "C1 and C2 now show **PASS**.",
  ]),
  ...pr("MOM-P07"),
  H2("Task 2 - GL vs trial balance control (D10)"),
  ...pr("MOM-P08"),
  P("Build C3 – C5 with SUMIFS on `tbl_gl[PLAmount]` and `tbl_tb_control[PL_NetIncome_USD]`. IN30 will differ by **-85,000**. Investigation shows an accrual reversal in professional fees was posted in SAP after the extract was taken. In a real close you would re-extract; here you mark it **EXPLAINED** and fix it in the Capstone."),
  H2("Task 3 - duplicate billing rows (D4)"),
  ...pr("MOM-P09"),
  P("The `bill` sheet already has helper columns `RowKey`, `Occurrence`, `IsDuplicate`, `QtyClean`, `RevClean`. Build C6 (count of duplicates in the close month) and C7 (clean billing revenue minus GL Gross Sales, must be 0)."),
  H2("Task 4 - the forecast trap (D5)"),
  P("Run the L1 prompt first and note the answer, then the L3 prompt."),
  ...pr("MOM-P10a"),
  ...pr("MOM-P10b"),
  ...verifyBox(["The forecast export contains `ProfitCenter = ALL` subtotal rows. Any total that does not exclude them is exactly double. Your Variance formulas must use the criterion `\"<>ALL\"`.", "Record both answers in the Prompt Log. This is the single most useful example to show your manager of why grounding matters."]),
  ...doneBox([
    "Checks C1 – C8 show: PASS, PASS, PASS, PASS, **EXPLAINED (D10 timing)**, **HANDLED - excluded via RevClean**, PASS, **TRAP PRESENT - handled**.",
    "The **map** sheet contains GL 540050.",
    "Your Prompt Log shows the two forecast answers side by side.",
  ]),
];

const lab3 = [
  ...labHeader("Lab 3", "Variance table and grounded Copilot exploration", 60, "Complete the Variance sheet with formulas, then use Copilot (Chat only) to rank, explain and challenge - verifying every figure.", "MOM-P13 – P16, P18, P19"),
  H2("Part A - formulas (25 min)"),
  ...steps([
    "On **Variance**, row 5 (Gross Sales) is complete. Copy its pattern down rows 6 – 16 for Actual (C), Budget (D), Var (E), Var % (F), Material? (G), Forecast (H), Var vs FC (I), Prior Year (J), Var vs PY (K).",
    "Read the Forecast formula carefully: it includes `\"<>ALL\"`. Keep it.",
    "Complete the **EBIT by business unit** block (SUMIFS by `PCnum` / `ProfitCenter`).",
    "Check: the **UNMAPPED** row shows 0 and the BU total equals the EBIT variance.",
  ]),
  H2("Part B - Copilot in Chat only (30 min)"),
  ...pr("MOM-P13"), ...pr("MOM-P14"), ...pr("MOM-P15"), ...pr("MOM-P16"),
  H3("Use Copilot to argue against you"),
  ...pr("MOM-P18"),
  H3("Make Copilot show its sources"),
  ...pr("MOM-P19"),
  ...doneBox([
    `EBIT actual **${usd2(K.subtotals.EBIT.Actual)}**, budget **${usd2(K.subtotals.EBIT.Budget)}**, variance **${usd2(K.subtotals.EBIT.Var_vs_Budget)}**.`,
    "**Material? = YES** on exactly four lines: Gross Sales, Raw Materials, Freight Outbound, Inventory Adjustments.",
    "BU block total equals the EBIT variance.",
    "At least three Copilot answers logged, each with a cell it was verified against.",
  ]),
];

const lab4 = [
  ...labHeader("Lab 4", "Price / volume / mix with Python in Excel", 60, "Split the gross sales variance into price, mix, volume and new products - reproducibly, with a check that must be zero.", "MOM-P20, P21, P22"),
  H2("The method"),
  ...table(["Component", "Formula (budgeted products only)"], [
    ["Price", "Σ (APᵢ − BPᵢ) × AQᵢ"],
    ["Mix", "Σ (AQᵢ − AQtotal × BMixᵢ) × BPᵢ   where BMixᵢ = BQᵢ / BQtotal"],
    ["Volume", "(AQtotal − BQtotal) × Σ (BMixᵢ × BPᵢ)"],
    ["New products", "Actual revenue of products with zero budget quantity (SF-405, **D6**)"],
    ["Check", "Price + Mix + Volume + New products − (Actual revenue − Budget revenue) = 0"],
  ], [2000, 7360]),
  P("AP / BP = actual / budget price per MT; AQ / BQ = actual / budget quantity. The PVM sheet columns A – F already pull clean (de-duplicated) quantities and revenue for September."),
  H2("Steps"),
  ...steps([
    "Ask Copilot to generate the Python with MOM-P20.",
    "Before running anything, paste the generated code into a Chat-only conversation with MOM-P21 and read the explanation (read-before-run).",
    "Compare it with the reference code below. Differences are fine if the logic is the same.",
    "Create a sheet `PVM_Python`, enter a Python cell (**Formulas → Insert Python** or type `=PY(`) [VERIFY], paste the code and run it (Ctrl+Enter).",
    "Optional stretch: complete the formula columns G – N on the PVM sheet (row 5 is the worked example) and check they agree with Python.",
  ]),
  ...pr("MOM-P20"),
  ...pr("MOM-P21"),
  H3("Reference code (tested against the lab data)"),
  ...code(PYCODE.trimEnd()),
  H2("Interpret"),
  ...pr("MOM-P22"),
  ...doneBox([
    `Python output: Price **${usd(K.pvm_total.Price)}**, Mix **${usd(K.pvm_total.Mix)}**, Volume **${usd(K.pvm_total.Volume)}**, New products **${usd(K.pvm_total.NewProducts)}**, Total **${usd(K.pvm_total.Total)}**, Check **0**.`,
    "Total equals the Gross Sales variance on the Variance sheet (Checks C9 and C10 = 0 if you completed the formula version).",
    "You can explain in two sentences why Sealants has favourable price and adverse mix.",
  ]),
];

const lab5 = [
  ...labHeader("Lab 5", "Cost drivers: freight, raw materials, one-offs", 45, "Turn the three big cost variances into explained drivers.", "MOM-P23, P24, P25"),
  H2("Part A - freight (15 min)"),
  P("On **Drivers**, row 5 (US10) is complete. Copy the pattern for DE20 and IN30. Effects use P&L sign (negative = adverse): Volume = −(actual − budget shipments) × budget rate; Rate = −(actual − budget rate) × actual shipments; Expedited = −expedited cost (GL 540050)."),
  ...pr("MOM-P23"),
  H2("Part B - raw materials (15 min)"),
  P("Complete B18 (volume/mix effect = standard cost on actual volume − budget) and B19 (rate effect = actual − standard cost on actual volume). Standard cost comes from `SAP_Material_StdCost`."),
  ...pr("MOM-P24"),
  H2("Part C - find the one-off (15 min)"),
  ...pr("MOM-P25"),
  ...doneBox([
    `Freight: DE20 rate effect **${usd(-K.freight.DE20.RateEffect)}**, DE20 expedited **${usd(-K.freight.DE20.Expedited)}**, US10 volume effect **${usd(-K.freight.US10.VolumeEffect)}**; Checks C11 = 0.`,
    `Raw materials: rate **${usd(K.raw_materials.RateEffect)}**, volume/mix **${usd(K.raw_materials.VolumeMixEffect)}**; Checks C12 = 0.`,
    "One-off identified: GL 545000 inventory write-off, US10, Elastomers, 1,200,000.",
    "Checks sheet overall status: **READY FOR ANALYSIS**.",
  ]),
];

const lab6 = [
  ...labHeader("Lab 6", "Commentary: =COPILOT() drafts, analyst finals", 45, "Generate draft commentary inside the grid, then edit it into release-quality text that ties to the model.", "MOM-P26 – P29, P31"),
  P("Go to **Commentary**. Column C is your driver evidence (write a cell reference and a few words from Labs 4 – 5). Column D is the Copilot draft. Column E is the only text that leaves the team."),
  H2("Part A - unguarded vs guarded drafts"),
  ...pr("MOM-P27"), ...pr("MOM-P28"),
  ...verifyBox(["Compare the two drafts for the Inventory Adjustments row. The unguarded version often invents a cause (e.g. 'obsolete stock'). The guarded version should only restate your evidence.", "=COPILOT() results can change when the sheet recalculates. Once you accept a draft, **Copy → Paste Values** it. [VERIFY]"]),
  H2("Part B - classify and draft in the pane"),
  ...pr("MOM-P26"), ...pr("MOM-P29"),
  H2("Part C - edit and tie out"),
  ...steps(["Write the final commentary in column E. Lead with the amount, then drivers, then any open question.", "Run MOM-P31 on your column E text.", "Fix every 'No' in the tie-out before you finish."]),
  ...pr("MOM-P31"),
  ...doneBox(["Four rows of final commentary (Gross Sales, Raw Materials, Freight Outbound, Inventory Adjustments).", "Tie-out table: every figure 'Yes'.", "Column D and column E are visibly different - you edited, not copied."]),
];

const lab7 = [
  ...labHeader("Lab 7", "Management pack in Word, PowerPoint and Outlook", 60, "Produce the one-page commentary, an 8-slide deck and a cover email - then tie out every number.", "MOM-P32 – P37"),
  H2("Word (20 min)"),
  P("Copy the Commentary!E text and the EBIT summary into a Word document named `Sep26_Management_Commentary_DRAFT.docx` saved in OneDrive/SharePoint so Copilot can reference it."),
  ...pr("MOM-P32"), ...pr("MOM-P35"),
  H2("PowerPoint (20 min)"),
  ...pr("MOM-P33"), ...pr("MOM-P36"),
  P("Paste charts from Excel (EBIT bridge, PVM) into the [CHART] placeholders. Do not let Copilot redraw charts from numbers it typed."),
  H2("Outlook and CFO prep (20 min)"),
  ...pr("MOM-P34"), ...pr("MOM-P37"),
  ...callout("Do not send", ["Save the email as a draft. In a real close, release happens only after the FP&A manager signs the tie-out."], C.WARN, "C0392B"),
  ...doneBox(["One-page Word commentary with summary table EBIT 7.50 / 9.29 / 8.78 / 8.30 (USD M: actual / budget / forecast / prior year).", "8-slide deck with speaker notes; charts pasted from Excel.", "Draft email, not sent.", "Tie-out table from MOM-P35 with zero mismatches."]),
];

const lab8 = [
  ...labHeader("Lab 8", "Agents: Variance Explainer and close gatekeeper", 30, "Turn L3 discipline into L4 agent instructions with guardrails, and test them.", "MOM-P38, P40, P11, P39, P41"),
  H2("Build the Variance Explainer (Agent Builder) [VERIFY]"),
  ...steps([
    "In Microsoft 365 Copilot, open **Agent Builder** and create a new agent named `Variance Explainer - Sep26 (training)`.",
    "Paste the MOM-P38 instructions.",
    "Add knowledge: your Word commentary from Lab 7, `GL_to_PL_Mapping.csv`, and the one-page materiality note from the kit.",
    "Run the 7-question test set (MOM-P40) and record pass/fail.",
  ]),
  ...pr("MOM-P38"), ...pr("MOM-P40"),
  H2("Optional: close gatekeeper and SAP drill-down design"),
  ...pr("MOM-P11"),
  ...pr("MOM-P39"),
  ...table(["SAP drill-down guardrail checklist", "Met?"], [
    ["Read-only service account; no create/change/post actions configured", ""],
    ["Agent asks for missing filters instead of guessing", ""],
    ["Every answer states the filters used", ""],
    ["Out-of-scope requests declined", ""],
    ["Answers labelled 'for investigation, not reporting'", ""],
  ], [7860, 1500]),
  ...pr("MOM-P41"),
  ...doneBox(["Variance Explainer: questions 1 – 5 answered with a source citation; questions 6 – 7 declined.", "(Optional) Gatekeeper returns NOT READY on STARTER and READY on your completed model."]),
];

const capstone = [
  H1("Capstone · Timed refresh-to-pack run (60 min, teams of 3 – 4)"),
  P("SAP has produced a later extract for September. Your job: run the whole cycle on it, against the clock, and record how long each step takes. This is how the team will measure the real time saving instead of guessing it."),
  H2("Steps"),
  ...steps([
    "Start the timer. Replace the September 2026 GL rows with `SAP_GL_Actuals_Sep2026_REEXTRACT.csv` (Power Query: filter out 2026/009 from `q_gl` and **Append** the re-extract; workbook route: replace the Sep-26 rows in `tbl_gl`).",
    "Refresh. Confirm Checks shows **READY FOR ANALYSIS** with C5 now **PASS**.",
    "Run MOM-P45 to explain what changed.",
    "Update the Commentary and the Word page for any changed figure (G&A and EBIT).",
    "Regenerate the deck summary slide and the cover email draft.",
    "Record minutes per step in the table below.",
  ]),
  ...pr("MOM-P45"),
  ...table(["Step", "Minutes", "Who"], [["Refresh + checks", "", ""], ["Variance + drivers review", "", ""], ["Commentary update + tie-out", "", ""], ["Word / deck / email", "", ""], ["Total", "", ""]], [5360, 2000, 2000]),
  ...doneBox([`Checks: all PASS / HANDLED / TRAP PRESENT, C5 **PASS**.`, `EBIT actual **${usd2(K.subtotals.EBIT.Actual + 85000)}** (up 85,000; G&A professional fees reversal).`, "Updated commentary and pack tie out.", "Time log completed."]),
  H2("Scoring (100)"),
  ...table(["Criterion", "Points", "Evidence"], [
    ["Model correct: checks READY, figures tie to the re-extract", "40", "Checks sheet, Variance EBIT"],
    ["Verification discipline: every Copilot figure tied to a cell", "20", "Prompt Log, tie-out tables"],
    ["Commentary quality: amount → driver → open question; no invented causes", "20", "Commentary!E, Word page"],
    ["Speed and teamwork: time log complete, clear hand-offs", "20", "Time log"],
  ], [5160, 1000, 3200]),
];

const appendices = [
  H1("Appendix A · Power Query M reference [VERIFY]"),
  P("Equivalent M for the Lab 1 custom steps. These use standard Power Query functions; generated M from Copilot should be checked against this."),
  ...code([
    'AddGL6     = Table.AddColumn(Source, "GL6", each Number.From([GLAccount]), Int64.Type),',
    'AddPC      = Table.AddColumn(AddGL6, "PCnum", each Number.From([ProfitCenter]), Int64.Type),',
    'AddPeriod  = Table.AddColumn(AddPC, "PeriodNum", each Number.From([Period]), Int64.Type),',
    'AddPL      = Table.AddColumn(AddPeriod, "PLAmount", each -[AmountUSD], type number),',
    '',
    '// DW budget',
    'AddYear    = Table.AddColumn(Source, "Year", each Number.From(Text.Start([Month], 4)), Int64.Type),',
    'AddPer     = Table.AddColumn(AddYear, "PeriodNum", each Number.From(Text.End([Month], 2)), Int64.Type),',
    'AddPLB     = Table.AddColumn(AddPer, "PLAmount", each if [LineType] = "Revenue" then [BudgetUSD] else -[BudgetUSD], type number)',
  ]),
  H1nb("Appendix B · Glossary"),
  ...table(["Term", "Meaning in this workshop"], [
    ["P&L sign", "Positive = favourable to profit; negative = adverse. Revenue positive, costs negative."],
    ["Material variance", "|variance| ≥ 3% of budget and ≥ USD 250,000 (lines with no budget: USD test only). Assumption A16."],
    ["PVM", "Price / volume / mix decomposition of the sales variance."],
    ["6+6 forecast", "Six months of actuals plus six months of forecast."],
    ["Standard cost", "Material-master cost per MT used to value volume at budget rates."],
    ["Chat only", "Copilot in Excel mode that does not edit the workbook. [VERIFY]"],
    ["Tie-out", "Matching every number in text to its source cell before release."],
  ], [2000, 7360]),
  H1nb("Appendix C · Planted defects you will meet"),
  ...table(["#", "Where", "What you see"], [
    ["D1", "SAP GL", "New GL 540050 (expedited freight, from Jul-26) missing from the mapping"],
    ["D2", "SAP vs DW", "Opposite sign conventions"],
    ["D3", "SAP vs DW", "Text keys with leading zeros vs numbers; period vs month formats"],
    ["D4", "SAP billing", "Duplicated September rows from a rerun"],
    ["D5", "DW forecast", "Subtotal rows (ProfitCenter = ALL) mixed with detail"],
    ["D6", "Budget sales", "New product with no budget"],
    ["D7", "SAP GL", "One-off write-off"],
    ["D8", "SAP GL", "Carrier rate spike at one plant"],
    ["D9", "Billing", "Mix shift between high- and low-price products"],
    ["D10", "TB control", "Late posting after the extract"],
  ], [700, 1800, 6860]),
  H1nb("Appendix D · Troubleshooting and fallbacks"),
  ...table(["Problem", "Fallback"], [
    ["Copilot mode selector looks different", "Use the default pane and add 'Do not change the workbook' to the prompt. Work on a copy."],
    ["=COPILOT() not available", "Use MOM-P29 in the Copilot pane and paste results into column D."],
    ["Python in Excel not available", "Complete the formula PVM (columns G – N) instead; same Done = values."],
    ["Agent Builder not available", "Use Copilot Chat with the knowledge files attached and the MOM-P38 instructions as the first message."],
    ["Copilot gives a number that does not match", "Ask MOM-P19 for sources; the cell is right, Copilot is not. Log it."],
    ["Power Query merge returns nulls everywhere", "Key types differ (text vs number). Convert both sides to Whole Number."],
  ], [3600, 5760]),
  H1nb("Appendix E · Assumption register (summary)"),
  ...table(["#", "Assumption", "If wrong"], [
    ["A1", "ERP is SAP S/4HANA (private cloud / on-prem)", "ECC: SAP ERP connector or BW; public cloud: OData APIs"],
    ["A2", "SAP BW/4HANA holds history and possibly plan", "Read S/4 CDS views directly"],
    ["A3", "'Warehouse' = enterprise DW with budget, forecast, volumes", "If physical-warehouse (WMS) data, it becomes a cost-driver source"],
    ["A4", "50k – 300k rows per month", "Above ~1M rows use the Data Model / Power BI"],
    ["A5", "Single reporting currency USD", "Add FX tables and an FX variance line"],
    ["A6", "GL → P&L mapping exists, kept in Excel", "Building it becomes Phase 0 work"],
    ["A8–A11", "M365 Copilot licences; Excel current channel; Python in Excel; Copilot Studio later", "Use fallbacks in Appendix D"],
    ["A13–A18", "Monthly close; 3–5 analysts + manager; Budget / Forecast / PY; materiality 3% & 250k", "Change Inputs sheet"],
    ["A19", "Five days split 1.0 / 1.5 / 0.5 / 1.0 / 1.0", "Measure with the Capstone time log"],
    ["A20", "2-day ILT, 12–16 participants", "Facilitator adjusts agenda"],
  ], [900, 4800, 3660]),
];

const doc = makeDoc([...cover, ...intro, ...scenario, ...lab0, ...lab1, ...lab2, ...lab3, ...lab4, ...lab5, ...lab6, ...lab7, ...lab8, ...capstone, ...appendices], "Momentive FP&A Copilot Lab Guide");
Packer.toBuffer(doc).then((b) => { const o = path.join(__dirname, "..", "kit", "02_Labs", "Momentive_FPA_Copilot_Lab_Guide.docx"); fs.writeFileSync(o, b); console.log("wrote", o); });
