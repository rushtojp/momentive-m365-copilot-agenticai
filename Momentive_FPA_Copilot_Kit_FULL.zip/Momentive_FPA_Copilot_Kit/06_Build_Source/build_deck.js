const fs = require("fs"), path = require("path");
const pptxgen = require("pptxgenjs");
const K = JSON.parse(fs.readFileSync(path.join(__dirname, "answer_key.json")));
const pres = new pptxgen(); pres.layout = "LAYOUT_WIDE"; pres.title = "Momentive FP&A Copilot Workshop";
pres.author = "Jayaprakash Balakrishnan";
const C = { NAVY: "21295C", DEEP: "065A82", TEAL: "1C7293", MINT: "16A0A0", GOLD: "E0A800", INK: "1F2937", GREY: "5B6573", LIGHT: "EEF4F8", WHITE: "FFFFFF", RED: "C0392B", GREEN: "2E7D32" };
const HF = "Cambria", BF = "Calibri";
const W = 13.333;

function base(title, kicker) {
  const s = pres.addSlide(); s.background = { color: C.WHITE };
  if (kicker) s.addText(kicker.toUpperCase(), { x: 0.6, y: 0.35, w: 10, h: 0.3, fontFace: BF, fontSize: 12, bold: true, color: C.TEAL, charSpacing: 2, margin: 0 });
  s.addText(title, { x: 0.6, y: 0.62, w: 12.1, h: 0.8, fontFace: HF, fontSize: 30, bold: true, color: C.NAVY, margin: 0, valign: "top" });
  s.addText("Fictional teaching data  ·  Aarvi Learning Solutions", { x: 0.6, y: 7.05, w: 8, h: 0.3, fontFace: BF, fontSize: 10, color: C.GREY, margin: 0 });
  return s;
}
function section(title, sub, num) {
  const s = pres.addSlide(); s.background = { color: C.NAVY };
  s.addText(num, { x: 0.8, y: 2.0, w: 3, h: 1.2, fontFace: HF, fontSize: 72, bold: true, color: C.GOLD, margin: 0 });
  s.addText(title, { x: 0.8, y: 3.2, w: 11.5, h: 1.0, fontFace: HF, fontSize: 40, bold: true, color: C.WHITE, margin: 0 });
  s.addText(sub, { x: 0.8, y: 4.25, w: 11.5, h: 0.8, fontFace: BF, fontSize: 20, color: "C9D6E3", margin: 0 });
  return s;
}
function card(s, x, y, w, h, head, body, opt = {}) {
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w, h, fill: { color: opt.fill || C.LIGHT }, line: { color: opt.fill || C.LIGHT }, rectRadius: 0.08 });
  s.addText(head, { x: x + 0.2, y: y + 0.15, w: w - 0.4, h: 0.45, fontFace: BF, fontSize: opt.hs || 18, bold: true, color: opt.hc || C.NAVY, margin: 0, valign: "top" });
  s.addText(body, { x: x + 0.2, y: y + 0.65, w: w - 0.4, h: h - 0.8, fontFace: BF, fontSize: opt.bs || 14, color: opt.bc || C.INK, margin: 0, valign: "top", paraSpaceAfter: 4 });
}
const bl = (items, size = 16) => items.map((t, i) => ({ text: t, options: { bullet: true, breakLine: i < items.length - 1, fontSize: size } }));
function tbl(s, rows, x, y, w, colW, fs = 13) {
  const head = rows[0].map((t) => ({ text: t, options: { bold: true, color: C.WHITE, fill: { color: C.NAVY }, fontFace: BF, fontSize: fs } }));
  const body = rows.slice(1).map((r, i) => r.map((t) => ({ text: String(t), options: { fontFace: BF, fontSize: fs, color: C.INK, fill: { color: i % 2 ? "F5F8FB" : C.WHITE } } })));
  s.addTable([head, ...body], { x, y, w, colW, border: { type: "solid", pt: 0.5, color: "C9D3DD" }, margin: 0.06, valign: "middle" });
}
const M = (n) => (n / 1e6).toFixed(2);

// 1 Title
{ const s = pres.addSlide(); s.background = { color: C.NAVY };
  s.addText("MOMENTIVE  ·  FP&A ENABLEMENT", { x: 0.8, y: 1.3, w: 11, h: 0.4, fontFace: BF, fontSize: 16, bold: true, color: C.GOLD, charSpacing: 3, margin: 0 });
  s.addText("Copilot-assisted variance analysis on SAP and data-warehouse data", { x: 0.8, y: 1.9, w: 11.5, h: 2.0, fontFace: HF, fontSize: 44, bold: true, color: C.WHITE, margin: 0, valign: "top" });
  s.addText("Two-day hands-on workshop  ·  Labs 0–8 and Capstone  ·  CRAFT prompt library", { x: 0.8, y: 4.1, w: 11.5, h: 0.5, fontFace: BF, fontSize: 20, color: "C9D6E3", margin: 0 });
  s.addText("All company codes, plants, products and figures in this workshop are fictional teaching data - not Momentive data.", { x: 0.8, y: 5.6, w: 11.5, h: 0.4, fontFace: BF, fontSize: 14, italic: true, color: "C9D6E3", margin: 0 });
  s.addText("Jayaprakash Balakrishnan  ·  Aarvi Learning Solutions  ·  October 2026", { x: 0.8, y: 6.3, w: 11.5, h: 0.4, fontFace: BF, fontSize: 14, color: "C9D6E3", margin: 0 });
  s.addNotes("Open by restating the business ask in the client's words: comparing SAP and warehouse data in Excel to explain P&L lines, sales variance and cost drivers takes about five working days, and the aim is to at least halve it. Make clear that every number in the workshop is invented so people can make mistakes safely."); }

// 2 Problem
{ const s = base("The ask: a five-day variance cycle, cut by at least half", "Why we are here");
  s.addText("5", { x: 0.6, y: 1.7, w: 2.2, h: 2.0, fontFace: HF, fontSize: 120, bold: true, color: C.NAVY, margin: 0 });
  s.addText("working days today to compare SAP actuals with warehouse budget, forecast and volumes and explain the P&L", { x: 0.6, y: 3.75, w: 3.6, h: 1.4, fontFace: BF, fontSize: 16, color: C.INK, margin: 0, valign: "top" });
  s.addChart(pres.charts.BAR, [{ name: "Days (assumed)", labels: ["Extract SAP + DW", "Clean, map, reconcile", "Calculate variances", "Investigate drivers", "Commentary + pack"], values: [1.0, 1.5, 0.5, 1.0, 1.0] }],
    { x: 4.6, y: 1.6, w: 8.2, h: 4.4, barDir: "bar", chartColors: [C.TEAL], catAxisLabelFontSize: 14, valAxisLabelFontSize: 12, catAxisLabelColor: C.INK, valAxisLabelColor: C.GREY,
      showValue: true, dataLabelFontSize: 13, dataLabelColor: C.INK, dataLabelFormatCode: "0.0", valGridLine: { color: "E5E7EB", size: 0.5 }, catAxisOrientation: "maxMin", valAxisMaxVal: 2, showLegend: false,
      showTitle: true, title: "Where the 5 days go - ASSUMPTION A19 (to be measured)", titleFontSize: 14, titleColor: C.GREY });
  s.addText("The split is our working assumption. The Capstone time log replaces it with the team's own measurement.", { x: 4.6, y: 6.2, w: 8.2, h: 0.5, fontFace: BF, fontSize: 14, italic: true, color: C.GREY, margin: 0 });
  s.addNotes("Ask the room whether this split looks right. If extraction and reconciliation are the biggest blocks, most of the saving comes from the data pipeline, not from Copilot - be upfront about that. We do not quote a percentage saving; the team measures it in the Capstone."); }

// 3 Golden rule
{ const s = base("Copilot explains and drafts. Excel produces the numbers.", "The golden rule");
  card(s, 0.6, 1.7, 5.9, 4.6, "Copilot does", "Explains drivers in plain English\nRanks and filters variances on request\nChallenges your hypothesis\nGenerates Power Query steps and Python for you to read\nDrafts commentary, the Word page, the deck and the email\nAnswers questions as a grounded agent", { bs: 17 });
  card(s, 6.85, 1.7, 5.9, 4.6, "Excel does (deterministic, repeatable)", "Power Query: extract, shape, map, refresh\nFormulas: variance table, checks, drivers\nPython in Excel: price / volume / mix\nChecks sheet: every month, same answer\nHumans: tie-out and sign-off before release", { bs: 17, fill: "E7F3F0" });
  s.addNotes("This rule runs through every lab. Copilot is fast at language and exploration, but the same question can produce different answers on different days. The numbers that go to the CFO come from Power Query, formulas and Python, and every Copilot figure is tied to a cell before anyone uses it."); }

// 4 Target design
{ const s = base("Target design: three layers, one human gate", "Architecture");
  const boxes = [
    [0.6, "SAP S/4HANA · SAP BW", "GL actuals, billing, standard cost, TB control", C.LIGHT],
    [0.6, "Data warehouse", "Budget, 6+6 forecast, volumes", C.LIGHT],
  ];
  card(s, 0.6, 1.8, 2.9, 1.7, "SAP S/4HANA · BW", "GL actuals, billing, std cost, TB control", { hs: 16, bs: 13 });
  card(s, 0.6, 3.8, 2.9, 1.7, "Data warehouse", "Budget, 6+6 forecast, volumes, shipments", { hs: 16, bs: 13 });
  card(s, 4.0, 1.8, 2.9, 3.7, "1 · Pipeline", "Power Query connectors\nGL→P&L mapping\nSign + key alignment\nChecks sheet (13 checks)\n\nRefresh monthly", { hs: 17, bs: 14, fill: "DCEBF5" });
  card(s, 7.3, 1.8, 2.7, 3.7, "2 · Analysis", "Variance table\nPVM (Python)\nFreight + RM drivers\nCopilot in Excel - Chat only", { hs: 17, bs: 14, fill: "DFF1EE" });
  card(s, 10.4, 1.8, 2.4, 3.7, "3 · Drafting", "=COPILOT() drafts\nWord · PowerPoint · Outlook\nAgents (Phase 3)", { hs: 17, bs: 14, fill: "FFF4D6" });
  [[3.5, 2.65], [3.5, 4.65], [6.9, 3.65], [10.0, 3.65]].forEach(([x, y]) => s.addShape(pres.shapes.RIGHT_ARROW, { x: x + 0.05, y: y - 0.15, w: 0.4, h: 0.3, fill: { color: C.TEAL }, line: { color: C.TEAL } }));
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: 4.0, y: 5.8, w: 8.8, h: 0.75, fill: { color: C.NAVY }, line: { color: C.NAVY }, rectRadius: 0.08 });
  s.addText("Human gate: Checks = READY before analysis  ·  tie-out + FP&A manager sign-off before release", { x: 4.2, y: 5.8, w: 8.4, h: 0.75, fontFace: BF, fontSize: 15, bold: true, color: C.WHITE, margin: 0, valign: "middle" });
  s.addNotes("Layer 1 is where most of the five days go today. Layer 2 uses Copilot in Chat-only mode on a controlled workbook. Layer 3 drafts the outputs. Two human gates: checks before analysis, tie-out before release."); }

// 5 Connectors clarification
{ const s = base("Getting SAP data in: what each Microsoft route is for", "Clarifying 'Copilot connectors'");
  tbl(s, [["Route", "Best for", "Fit for monthly P&L variance"],
    ["Power Query SAP HANA / SAP BW connectors in Excel", "Refreshable tables of actuals in the workbook", "Primary route. Needs HANA ODBC driver or SAP .NET Connector 3.0/3.1 per machine"],
    ["Fabric Dataflow Gen2 / Power BI semantic model", "Large volumes, shared curated model", "Use when rows exceed what Excel handles comfortably"],
    ["Microsoft 365 Copilot connectors (formerly Graph connectors)", "Indexing content so Copilot can search and cite it", "Not designed for aggregating P&L rows [VERIFY with Microsoft]"],
    ["Copilot Studio agent with SAP OData / SAP ERP connector", "Ad-hoc drill-down questions in Teams", "Phase 3: read-only investigation, not reporting"],
  ], 0.6, 1.7, 12.1, [3.6, 3.9, 4.6], 17);
  s.addText("In class, CSV extracts stand in for the SAP and DW connections. Every step after 'Get Data' is identical.", { x: 0.6, y: 6.3, w: 12, h: 0.45, fontFace: BF, fontSize: 15, italic: true, color: C.GREY, margin: 0 });
  s.addNotes("This corrects an easy misunderstanding from the scoping call. Enabling connectors so SAP data flows into Copilot is a sensible phase-2/3 idea for questions in Teams, but the monthly numbers should come through a refreshable Power Query pipeline. Driver requirements are from Microsoft Learn; the Copilot connector characterisation should be confirmed with Microsoft for the client's tenant."); }

// 6 Assumptions
{ const s = base("Assumptions we built on - tell us which are wrong", "Assumption register");
  tbl(s, [["#", "Assumption", "If wrong"],
    ["A1/A2", "SAP S/4HANA (private cloud / on-prem) plus SAP BW for history", "ECC → SAP ERP connector / BW extracts; public cloud → OData APIs"],
    ["A3", "'Warehouse' = enterprise DW with budget, forecast, volumes", "WMS data becomes a cost-driver source; budget comes from elsewhere"],
    ["A4", "50k–300k rows per month", "Above ~1M rows: Excel Data Model or Power BI model"],
    ["A5", "Single reporting currency (USD)", "Add FX tables and an FX variance line"],
    ["A6", "GL→P&L mapping exists but lives in a hand-kept sheet", "Building it is Phase 0 work"],
    ["A8–A11", "M365 Copilot licences, current Excel, Python in Excel, Copilot Studio later", "Fallbacks in the lab guide"],
    ["A16", "Materiality ≥3% and ≥USD 250k", "Change two input cells"],
    ["A19", "5 days = 1.0 / 1.5 / 0.5 / 1.0 / 1.0", "Measured in the Capstone"],
  ], 0.6, 1.65, 12.1, [1.2, 5.6, 5.3], 15);
  s.addNotes("These are the assumptions behind the design and the lab kit. A1, A3 and A19 change the design most. Ask Nazneen's team to correct them during the session."); }

// 7 Section CRAFT
section("CRAFT for finance", "One structure for every prompt - and a ladder from quick questions to agent instructions", "01").addNotes("Transition to the prompting framework used in every lab.");

// 8 CRAFT letters
{ const s = base("CRAFT, spelled out for an FP&A analyst", "The framework");
  const L = [["C", "Context", "Sep 2026 close, USD; P&L sign positive = favourable; sheets Variance, Drivers; tbl_gl is SAP"],
    ["R", "Role", "You are a senior FP&A analyst reviewing a month-end pack"],
    ["A", "Action", "ONE verb: identify · explain · compare · draft · reconcile"],
    ["F", "Format", "Table: P&L line | Var | Var % | Source cell"],
    ["T", "Target & tone", "For the FP&A manager; neutral; use ONLY the named sheets; say 'not available'"]];
  L.forEach(([l, n, ex], i) => { const x = 0.6 + i * 2.48;
    s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y: 1.75, w: 2.3, h: 4.6, fill: { color: i % 2 ? "E7F3F0" : C.LIGHT }, line: { color: i % 2 ? "E7F3F0" : C.LIGHT }, rectRadius: 0.08 });
    s.addText(l, { x, y: 1.9, w: 2.3, h: 1.1, align: "center", fontFace: HF, fontSize: 60, bold: true, color: C.TEAL, margin: 0 });
    s.addText(n, { x: x + 0.15, y: 3.05, w: 2.0, h: 0.45, align: "center", fontFace: BF, fontSize: 18, bold: true, color: C.NAVY, margin: 0 });
    s.addText(ex, { x: x + 0.18, y: 3.6, w: 1.95, h: 2.6, fontFace: BF, fontSize: 14, color: C.INK, margin: 0, valign: "top" }); });
  s.addNotes("Same five elements every time. The T carries the grounding rules that make answers checkable: use only these sheets, cite the cell, say not available."); }

// 9 Ladder
{ const s = base("The ladder: same task, four levels", "L1 → L4");
  tbl(s, [["Level", "What you add", "Example: explain the freight variance"],
    ["L1", "Action + Format", "\"Explain the freight variance.\""],
    ["L2", "+ Role, Context", "\"You are a logistics cost analyst. Our Variance sheet shows Freight Outbound vs budget for Sep 2026. Explain the variance.\""],
    ["L3", "All five + grounding", "Context + Drivers!A5:L8 · Role · split by entity · table Volume | Rate | Expedited · \"use ONLY the sheets, cite cells, say not available\""],
    ["L4", "Reusable instructions + guardrails", "Agent rule: read Drivers only, always split volume/rate/expedited, cite cells; if Checks!C11 ≠ 0 reply 'does not reconcile - escalate' and stop"],
  ], 0.6, 1.7, 12.1, [1.0, 2.9, 8.2], 17);
  s.addText("Default for anything that feeds the pack: L3.  L1 is for exploration only.", { x: 0.6, y: 6.2, w: 12, h: 0.5, fontFace: BF, fontSize: 17, bold: true, color: C.TEAL, margin: 0 });
  s.addNotes("Run the L1 and L3 versions live in Copilot so people see the difference. The Level Ladder sheet in the prompt library has two more worked tasks."); }

// 10 Grounding rules
{ const s = base("Four rules that make Copilot's answers checkable", "Grounding");
  const R = [["Use ONLY", "the named sheets and tables - no outside knowledge, no estimates"], ["Cite", "the sheet and cell for every number (follow up with MOM-P19)"], ["Say 'not available'", "when the data is missing - never fill the gap"], ["Chat only", "on the controlled workbook; edits only on a working copy [VERIFY mode names]"]];
  R.forEach(([h, b], i) => card(s, 0.6 + (i % 2) * 6.15, 1.75 + Math.floor(i / 2) * 2.35, 5.95, 2.1, h, b, { hs: 22, bs: 17 }));
  s.addNotes("These four rules are in the T element of every L3 prompt in the library. The fourth matters because Excel Copilot's editing modes can change a workbook; the controlled model stays in Chat-only mode."); }

// 11 Anti-patterns
{ const s = base("Prompts that hurt you in a close", "Anti-patterns");
  tbl(s, [["Anti-pattern", "What goes wrong", "Do instead"],
    ["\"What is total forecast for September?\"", "Sums subtotal rows - the answer doubles", "Name the exclusion rule; verify against the Checks sheet"],
    ["\"Explain why costs went up.\"", "Invents plausible causes", "Ground on the Drivers sheet; 'no causes not in the evidence'"],
    ["\"Make it sound better\" on commentary", "Rounds or drops figures", "'Keep every figure exactly'; ask for the figure list"],
    ["Copilot computes PVM in chat", "Not reproducible", "Generate Python; read before run; check = 0"],
    ["Agent Mode on the file of record", "Unreviewed edits", "Chat only; edit a copy"],
  ], 0.6, 1.7, 12.1, [3.9, 3.6, 4.6], 17);
  s.addNotes("Each of these appears as a live moment in the labs. The forecast-subtotal trap in Lab 2 is usually the one people remember."); }

// 12 Section labs
section("The labs", "Fictional Momentive-style close for September 2026 with ten planted defects", "02").addNotes("Transition into the lab kit.");

// 13 Dataset
{ const s = base("The lab data: a realistic close, deliberately imperfect", "Sample data");
  tbl(s, [["Extract", "Rows", "Planted defects"],
    ["SAP GL actuals FY25–FY26 (SAP sign, leading-zero text keys)", "4,633", "D1 unmapped GL · D2 sign · D3 keys · D7 write-off · D8 rate spike"],
    ["SAP billing (qty MT, revenue by material/segment)", "514", "D4 duplicate rows · D6 new product · D9 mix shift"],
    ["SAP trial-balance control + Sep re-extract", "63 + 226", "D10 late posting"],
    ["DW budget P&L, budget sales, 6+6 forecast, ops volumes", "1,584 · 288 · 2,028 · 99", "D2 all-positive · D5 subtotal rows"],
  ], 0.6, 1.7, 12.1, [5.6, 2.2, 4.3], 16);
  card(s, 0.6, 4.6, 3.9, 1.9, "3 company codes", "US10 · DE20 · IN30 (fictional plants)", { hs: 18, bs: 15 });
  card(s, 4.7, 4.6, 3.9, 1.9, "4 business units", "Specialty Fluids · Sealants & Adhesives · Elastomers · Coatings & Additives", { hs: 18, bs: 15 });
  card(s, 8.8, 4.6, 3.9, 1.9, "13 products", "incl. SF-405 Low-VOC fluid launched June with no budget", { hs: 18, bs: 15 });
  s.addNotes("Every defect maps to a check on the Checks sheet and to at least one lab. The facilitator guide has the full defect map and expected values."); }

// 14 Lab map
{ const s = base("Nine labs and a capstone", "Lab map");
  tbl(s, [["Lab", "What you build", "Copilot surface", "Done ="],
    ["0", "Orientation, L1 vs L3", "Excel - Chat only", "Two logged prompts"],
    ["1", "Power Query: SAP + DW, signs, keys, mapping", "Copilot Chat helps with M", "4,633 rows; Sep EBIT ties"],
    ["2", "Checks sheet (C1–C8)", "Excel - Chat only, Outlook", "PASS / EXPLAINED / HANDLED"],
    ["3", "Variance table + BU view", "Excel - Chat only", "EBIT var ties; 4 material lines"],
    ["4", "Price / volume / mix", "Python in Excel via Copilot", "Check = 0; ties to sales var"],
    ["5", "Freight, raw materials, one-offs", "Excel - Chat only", "C11, C12 = 0; write-off found"],
    ["6", "Commentary", "=COPILOT(), Excel pane", "Tie-out all Yes"],
    ["7", "Management pack", "Word, PowerPoint, Outlook", "Zero mismatches"],
    ["8", "Variance Explainer agent", "Agent Builder", "5 cited, 2 declined"],
    ["Cap", "Timed refresh-to-pack on the re-extract", "All", "READY; time log"],
  ], 0.6, 1.6, 12.1, [0.8, 4.6, 3.4, 3.3], 14);
  s.addNotes("Every lab ends with a binary Done check. Participants who fall behind in Lab 1 switch to the STARTER workbook, which already contains the loaded tables."); }

// 15 Agenda
{ const s = base("Agenda", "Two days");
  card(s, 0.6, 1.7, 5.95, 4.9, "Day 1 - pipeline and analysis", "09:30  The 5-day close problem · target design\n10:00  CRAFT for finance\n11:00  Lab 0  Orientation\n11:20  Lab 1  Power Query: SAP + DW\n13:05  Lab 2  Checks sheet\n14:20  Lab 3  Variance + grounded Copilot\n15:20  Day 1 review", { bs: 16 });
  card(s, 6.75, 1.7, 5.95, 4.9, "Day 2 - drivers, drafting, agents", "09:45  Lab 4  PVM in Python\n11:00  Lab 5  Cost drivers\n11:45  Lab 6  Commentary\n13:15  Lab 7  Management pack\n14:30  Lab 8  Agents\n15:00  Capstone: timed run\n16:00  Debrief and rollout plan", { bs: 16, fill: "E7F3F0" });
  s.addNotes("Assumption A20: two days, 12 to 16 participants, breaks at 10:45, 12:20, 14:05 on day 1 and 10:45, 12:30, 14:15 on day 2."); }

// 16 Trust loop
{ const s = base("The verification loop in every lab", "Trust, then verify");
  const st = ["Prompt (L3)", "Copilot answer", "Ask for sources (MOM-P19)", "Tie to cell / check", "Log in Prompt Log"];
  st.forEach((t, i) => { const x = 0.6 + i * 2.5;
    s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y: 2.4, w: 2.15, h: 1.5, fill: { color: i === 3 ? C.NAVY : C.LIGHT }, line: { color: i === 3 ? C.NAVY : C.LIGHT }, rectRadius: 0.1 });
    s.addText(t, { x: x + 0.1, y: 2.4, w: 1.95, h: 1.5, align: "center", valign: "middle", fontFace: BF, fontSize: 16, bold: true, color: i === 3 ? C.WHITE : C.NAVY, margin: 0 });
    if (i < 4) s.addShape(pres.shapes.RIGHT_ARROW, { x: x + 2.17, y: 3.0, w: 0.3, h: 0.3, fill: { color: C.TEAL }, line: { color: C.TEAL } }); });
  s.addText(bl(["If the figure and the cell disagree, the cell wins - fix the prompt, not the number.", "Log every disagreement: it becomes your team's playbook of prompts that work.", "Nothing leaves the team until the tie-out table (MOM-P31, MOM-P35) has zero mismatches."], 17), { x: 0.6, y: 4.4, w: 12, h: 2.0, fontFace: BF, color: C.INK, paraSpaceAfter: 8, margin: 0 });
  s.addNotes("This loop is the core habit. It is what makes Copilot safe to use on financial results."); }

// 17 Section debrief
section("Debrief: the September story", "What the model shows once every check is green (facilitator reveal after Lab 5)", "03").addNotes("Hold these slides until after Lab 5 so participants discover the story themselves.");

// 18 EBIT bridge
{ const s = base(`EBIT ${M(K.subtotals.EBIT.Actual)}M vs budget ${M(K.subtotals.EBIT.Budget)}M: a cost story, not a sales story`, "September 2026");
  const lines = K.variance_table.filter((v) => Math.abs(v.Var_vs_Budget) > 40000);
  s.addChart(pres.charts.BAR, [{ name: "Var vs budget (USD M)", labels: lines.map((v) => v.PLLine), values: lines.map((v) => +(v.Var_vs_Budget / 1e6).toFixed(2)) }],
    { x: 0.6, y: 1.6, w: 7.6, h: 5.2, barDir: "bar", chartColors: [C.TEAL], catAxisOrientation: "maxMin", catAxisLabelFontSize: 13, valAxisLabelFontSize: 12,
      catAxisLabelColor: C.INK, valAxisLabelColor: C.GREY, showValue: true, dataLabelFontSize: 12, dataLabelFormatCode: "0.00", valGridLine: { color: "E5E7EB", size: 0.5 }, showLegend: false,
      invertIfNegative: false, catAxisLabelPos: "low" });
  s.addText(bl([`Gross sales +${M(K.variance_table[0].Var_vs_Budget)}M: new SF-405 and price`, `Raw materials ${M(K.variance_table[2].Var_vs_Budget)}M: siloxane rate ${M(K.raw_materials.RateEffect)}M`, `One-off write-off -1.20M at US10 Elastomers`, `Freight ${M(K.variance_table[6].Var_vs_Budget)}M: DE20 expedited and carrier rate`, `EBIT ${M(K.subtotals.EBIT.Var_vs_Budget)}M vs budget; ${M(K.subtotals.EBIT.Actual - K.subtotals.EBIT.Forecast)}M vs forecast`], 16),
    { x: 8.5, y: 1.7, w: 4.3, h: 4.9, fontFace: BF, color: C.INK, paraSpaceAfter: 10, margin: 0, valign: "top" });
  s.addNotes("Figures are from the fictional lab data and are reproduced exactly from the answer key. The usual first hypothesis - weak sales volumes - is wrong: sales were favourable and the miss is cost-driven. That is the point of MOM-P18."); }

// 19 PVM
{ const s = base("Sales: favourable price and new product, adverse mix", "Price / volume / mix");
  const p = K.pvm_total;
  s.addChart(pres.charts.BAR, [{ name: "USD M", labels: ["Price", "Mix", "Volume", "New products", "Total"], values: [p.Price, p.Mix, p.Volume, p.NewProducts, p.Total].map((x) => +(x / 1e6).toFixed(2)) }],
    { x: 0.6, y: 1.6, w: 7.2, h: 5.0, barDir: "col", chartColors: [C.DEEP], catAxisLabelFontSize: 14, valAxisLabelFontSize: 12, catAxisLabelColor: C.INK, valAxisLabelColor: C.GREY,
      showValue: true, dataLabelFontSize: 13, dataLabelFormatCode: "0.00", valGridLine: { color: "E5E7EB", size: 0.5 }, showLegend: false });
  card(s, 8.2, 1.7, 4.5, 2.3, "Sealants & Adhesives", `Price +${M(K.pvm_by_bu["Sealants & Adhesives"].Price)}M, but mix ${M(K.pvm_by_bu["Sealants & Adhesives"].Mix)}M as volume moved from SA-240 glazing adhesive to cheaper SA-120 sealant.`, { bs: 15 });
  card(s, 8.2, 4.2, 4.5, 2.3, "Specialty Fluids", `SF-405 launched in June with no budget: +${M(K.pvm_total.NewProducts)}M. Kept in its own bucket so the PVM check still equals zero.`, { bs: 15, fill: "E7F3F0" });
  s.addNotes("Computed in Python in Excel in Lab 4 and cross-checked with formulas. Check = 0 and the total equals the gross sales variance."); }

// 20 Governance
{ const s = base("Controls that keep this safe", "Governance");
  tbl(s, [["Control", "How it works in the model"],
    ["Copilot never produces a reported figure", "All figures from Power Query, formulas, Python; 13 checks must be READY"],
    ["Controlled workbook in Chat-only mode", "Edits by Copilot only on a working copy"],
    ["Draft vs final text kept apart", "Commentary column D (Copilot) vs column E (analyst, signed)"],
    ["Tie-out before release", "MOM-P31 / MOM-P35 tables; zero mismatches"],
    ["Sensitivity labels and audience", "Pre-release P&L labelled Confidential; pack distribution list only"],
    ["Agents are read-only and refuse out-of-scope", "Tested with a 7-question script before use"],
  ], 0.6, 1.7, 12.1, [4.7, 7.4], 17);
  s.addNotes("Align with the client's information-protection policy; if the company's results are price-sensitive before release, restrict to the insider list."); }

// 21 Rollout
{ const s = base("From workshop to the real close", "Rollout plan (durations are assumptions)");
  const ph = [["Phase 0", "Discovery", "1 week", "Confirm assumptions; time today's 5 days step by step"],
    ["Phase 1", "Pipeline", "2–3 weeks", "SAP + DW connectors, mapping table, Checks; reproduce one past month exactly"],
    ["Phase 2", "Analysis pack", "2 weeks", "Variance, PVM, drivers, prompt library; parallel run of one live month"],
    ["Phase 3", "Measure", "1 close", "Time log vs baseline - the only saving we report"],
    ["Phase 4", "Agents", "2–3 weeks", "Optional: Variance Explainer; read-only SAP drill-down in Teams"]];
  ph.forEach(([a, b, c, dd], i) => { const x = 0.6 + i * 2.48;
    s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y: 1.75, w: 2.3, h: 4.7, fill: { color: i === 3 ? "FFF4D6" : C.LIGHT }, line: { color: i === 3 ? "FFF4D6" : C.LIGHT }, rectRadius: 0.08 });
    s.addText(a, { x: x + 0.15, y: 1.9, w: 2.0, h: 0.35, fontFace: BF, fontSize: 13, bold: true, color: C.TEAL, margin: 0 });
    s.addText(b, { x: x + 0.15, y: 2.25, w: 2.0, h: 0.5, fontFace: HF, fontSize: 20, bold: true, color: C.NAVY, margin: 0 });
    s.addText(c, { x: x + 0.15, y: 2.8, w: 2.0, h: 0.35, fontFace: BF, fontSize: 14, color: C.GREY, margin: 0 });
    s.addText(dd, { x: x + 0.15, y: 3.3, w: 2.0, h: 3.0, fontFace: BF, fontSize: 14, color: C.INK, margin: 0, valign: "top" }); });
  s.addNotes("The saving is reported only after Phase 3 measurement against the Phase 0 baseline. No percentage is promised before that."); }

// 22 Verify
{ const s = base("Re-check in your tenant before go-live", "Verification register");
  tbl(s, [["Item", "Status", "Re-check"],
    ["Excel Copilot modes (Allow editing / Plan / Chat only)", "Version-sensitive", "Open the pane in the tenant"],
    ["Agent Mode in Excel generally available", "Version-sensitive", "Confirm in tenant"],
    ["=COPILOT() worksheet function", "Version-sensitive", "Type =COPILOT( ; check channel/licence"],
    ["Python in Excel xl() syntax", "Version-sensitive", "Run Lab 4 code"],
    ["Finance in M365 Copilot - SAP coverage", "Unverified", "Ask Microsoft account team"],
    ["Copilot Studio SAP connectors", "Version-sensitive", "Power Platform admin"],
    ["Copilot Cowork availability", "Unverified", "Tenant admin"],
    ["Time-saving percentages", "Omitted by design", "Measured in Phase 3"],
  ], 0.6, 1.6, 12.1, [6.0, 2.4, 3.7], 16);
  s.addNotes("Full register with sources is in the prompt library workbook. Copilot features change frequently; anything version-sensitive is re-checked during the dry run."); }

// 23 Close
{ const s = pres.addSlide(); s.background = { color: C.NAVY };
  s.addText("Next steps", { x: 0.8, y: 1.0, w: 11, h: 0.9, fontFace: HF, fontSize: 40, bold: true, color: C.WHITE, margin: 0 });
  s.addText(bl(["Correct the assumption register (A1, A3, A19 first)", "Dry-run the labs in the Momentive tenant; capture real screenshots", "Agree Phase 0 owner and the baseline time log", "Nominate the GL-mapping owner and the pack sign-off owner"], 22),
    { x: 0.8, y: 2.2, w: 11.5, h: 3.5, fontFace: BF, color: C.WHITE, paraSpaceAfter: 14, margin: 0, valign: "top" });
  s.addNotes("Close by asking for the three answers that change the design most: SAP landscape, what 'warehouse' means, and the real split of the five days."); }

pres.writeFile({ fileName: path.join(__dirname, "..", "kit", "01_Presentations", "Momentive_FPA_Copilot_Workshop_Deck.pptx") }).then((f) => console.log("wrote", f));
