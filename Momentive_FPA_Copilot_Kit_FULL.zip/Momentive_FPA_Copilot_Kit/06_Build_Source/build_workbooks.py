"""Builds SOLUTION and STARTER variance-model workbooks from the CSV extracts.
STARTER is generated from the SOLUTION spec (same builder, mode flag) so they never drift."""
import json, os, sys
import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.worksheet.table import Table, TableStyleInfo
from openpyxl.comments import Comment
from openpyxl.utils import get_column_letter

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
D = os.path.join(ROOT, "kit", "03_Sample_Data")
KEY = json.load(open(os.path.join(ROOT, "build", "answer_key.json")))
OUTDIR = os.path.join(ROOT, "kit", "04_Workbooks"); os.makedirs(OUTDIR, exist_ok=True)

NAVY, TEAL, MINT, GOLD = "21295C", "1C7293", "16A0A0", "E0A800"
F = "Calibri"
HDR_FILL = PatternFill("solid", fgColor=NAVY); INPUT_FILL = PatternFill("solid", fgColor="FFF2CC")
SUB_FILL = PatternFill("solid", fgColor="DDEBF7"); FIX_FILL = PatternFill("solid", fgColor="E2EFDA")
WARN_FILL = PatternFill("solid", fgColor="FCE4D6")
thin = Side(style="thin", color="BFBFBF"); BOX = Border(top=thin, bottom=thin, left=thin, right=thin)
USD = '#,##0;[Red](#,##0);"-"'; PCT = '0.0%;[Red]-0.0%;"-"'

gl = pd.read_csv(f"{D}/SAP_Extracts/SAP_GL_Actuals_FY2025_FY2026.csv", dtype={"Period": str, "ProfitCenter": str, "GLAccount": str})
bill = pd.read_csv(f"{D}/SAP_Extracts/SAP_Billing_Sales_FY2025_FY2026.csv", dtype={"Period": str, "ProfitCenter": str})
tb = pd.read_csv(f"{D}/SAP_Extracts/SAP_TrialBalance_Control.csv", dtype={"Period": str})
std = pd.read_csv(f"{D}/SAP_Extracts/SAP_Material_StdCost.csv", dtype={"ProfitCenter": str})
bud = pd.read_csv(f"{D}/DW_Extracts/DW_Budget_PL_FY2026.csv")
bsales = pd.read_csv(f"{D}/DW_Extracts/DW_Budget_Sales_FY2026.csv")
fc = pd.read_csv(f"{D}/DW_Extracts/DW_Forecast_6plus6_FY2026.csv", dtype={"ProfitCenter": str})
ops = pd.read_csv(f"{D}/DW_Extracts/DW_Ops_Volumes_FY2026.csv")
mp = pd.read_csv(f"{D}/Reference/GL_to_PL_Mapping.csv")

PCS = KEY["profit_centers"]; LINES = KEY["pl_lines"]
SECTION = {r.PLLine: r.PLSection for r in mp.itertuples()}
MATERIALS = list(std.Material)
ENTITIES = list(KEY["companies"].keys())


def style_header(ws, row, ncol, start=1):
    for c in range(start, start + ncol):
        cell = ws.cell(row=row, column=c)
        cell.font = Font(name=F, size=11, bold=True, color="FFFFFF"); cell.fill = HDR_FILL
        cell.alignment = Alignment(wrap_text=True, vertical="center", horizontal="center")


def title(ws, text, sub):
    ws["A1"] = text; ws["A1"].font = Font(name=F, size=16, bold=True, color=NAVY)
    ws["A2"] = sub; ws["A2"].font = Font(name=F, size=11, italic=True, color="595959")


def write_df(ws, df, start_row=1, table_name=None, formulas=None):
    """Write df; formulas = {col_name: template with {r}} appended as extra columns."""
    cols = list(df.columns) + list((formulas or {}).keys())
    for j, c in enumerate(cols, 1): ws.cell(row=start_row, column=j, value=c)
    style_header(ws, start_row, len(cols))
    for i, row in enumerate(df.itertuples(index=False), start_row + 1):
        for j, v in enumerate(row, 1): ws.cell(row=i, column=j, value=v)
        for j, (c, tmpl) in enumerate((formulas or {}).items(), len(df.columns) + 1):
            ws.cell(row=i, column=j, value=tmpl.format(r=i))
    last = start_row + len(df)
    if table_name:
        t = Table(displayName=table_name, ref=f"A{start_row}:{get_column_letter(len(cols))}{last}")
        t.tableStyleInfo = TableStyleInfo(name="TableStyleLight9", showRowStripes=True)
        ws.add_table(t)
    ws.freeze_panes = ws.cell(row=start_row + 1, column=1)
    return last


def build(mode):
    sol = mode == "SOLUTION"
    wb = Workbook(); ws = wb.active; ws.title = "README"

    # ---------------- Inputs ----------------
    inp = wb.create_sheet("Inputs")
    title(inp, "Model inputs", "Yellow cells are the only cells you edit. Everything else recalculates.")
    rows = [("Close fiscal year", 2026), ("Close period (1-12)", 9), ("Close month key (DW format)", '=B4&"-"&TEXT(B5,"00")'),
            ("Prior year", "=B4-1"), ("Materiality - % of budget", 0.03), ("Materiality - absolute USD", 250000),
            ("Reconciliation tolerance USD", 1)]
    for i, (k, v) in enumerate(rows, 4):
        inp.cell(row=i, column=1, value=k); c = inp.cell(row=i, column=2, value=v)
        if not str(v).startswith("="): c.fill = INPUT_FILL
    inp["B8"].number_format = "0%"; inp["B9"].number_format = USD
    inp["A12"] = "Assumption A16: materiality = variance at least 3% of budget AND at least USD 250,000; lines with no budget qualify on the USD test alone. Change B8/B9 to the client's real thresholds."
    YR, PER, MON, PY, MPCT, MABS, TOL = "Inputs!$B$4", "Inputs!$B$5", "Inputs!$B$6", "Inputs!$B$7", "Inputs!$B$8", "Inputs!$B$9", "Inputs!$B$10"
    inp.column_dimensions["A"].width = 34; inp.column_dimensions["B"].width = 16

    # ---------------- Mapping ----------------
    m = wb.create_sheet("map")
    mdf = mp.copy()
    if sol:
        mdf = pd.concat([mdf, pd.DataFrame([dict(GLAccount=540050, PLLine="Freight Outbound", PLSection="Cost of Sales", LineOrder=7, LineType="Cost")])])
    last_map = write_df(m, mdf, table_name="tbl_map")
    if sol:
        for c in range(1, 6): m.cell(row=last_map, column=c).fill = FIX_FILL
        m.cell(row=last_map, column=1).comment = Comment("Added in Lab 2 to resolve planted defect D1 (new expedited-freight account opened Jul-26, missing from the mapping).", "Lab kit")
    ML = 60  # allow learners to add rows
    MAP_GL, MAP_LINE = f"map!$A$2:$A${ML}", f"map!$B$2:$B${ML}"

    # ---------------- GL actuals ----------------
    g = wb.create_sheet("gl")
    n_gl = len(gl) + 1
    write_df(g, gl, table_name="tbl_gl", formulas={
        "GL6": "=VALUE(F{r})", "PCnum": "=VALUE(D{r})", "PeriodNum": "=VALUE(C{r})",
        "PLLine": f'=IFERROR(INDEX({MAP_LINE},MATCH(I{{r}},{MAP_GL},0)),"UNMAPPED")',
        "PLAmount": "=-H{r}"})
    GLR = lambda col: f"gl!${col}$2:${col}${n_gl}"

    # ---------------- Budget, Forecast ----------------
    b = wb.create_sheet("bud"); n_b = len(bud) + 1
    write_df(b, bud, table_name="tbl_budget", formulas={
        "Year": "=VALUE(LEFT(A{r},4))", "PeriodNum": "=VALUE(RIGHT(A{r},2))",
        "PLAmount": '=IF(E{r}="Revenue",F{r},-F{r})'})
    BR = lambda col: f"bud!${col}$2:${col}${n_b}"
    f = wb.create_sheet("fc"); n_f = len(fc) + 1
    write_df(f, fc, table_name="tbl_forecast", formulas={
        "Year": "=VALUE(LEFT(A{r},4))", "PeriodNum": "=VALUE(RIGHT(A{r},2))",
        "PLAmount": '=IF(E{r}="Revenue",F{r},-F{r})'})
    FR = lambda col: f"fc!${col}$2:${col}${n_f}"

    # ---------------- Billing ----------------
    bl = wb.create_sheet("bill"); n_bl = len(bill) + 1
    write_df(bl, bill, table_name="tbl_billing", formulas={
        "PeriodNum": "=VALUE(B{r})", "RowKey": '=A{r}&"|"&B{r}&"|"&C{r}&"|"&E{r}&"|"&G{r}',
        "Occurrence": "=COUNTIF($K$2:K{r},K{r})", "IsDuplicate": "=IF(L{r}>1,1,0)",
        "QtyClean": "=IF(M{r}=0,H{r},0)", "RevClean": "=IF(M{r}=0,I{r},0)"})
    BLR = lambda col: f"bill!${col}$2:${col}${n_bl}"

    bs = wb.create_sheet("bsales"); n_bs = len(bsales) + 1
    write_df(bs, bsales, table_name="tbl_budget_sales")
    BSR = lambda col: f"bsales!${col}$2:${col}${n_bs}"
    o = wb.create_sheet("ops"); n_o = len(ops) + 1
    write_df(o, ops, table_name="tbl_ops")
    OR_ = lambda col: f"ops!${col}$2:${col}${n_o}"
    t = wb.create_sheet("tb"); n_t = len(tb) + 1
    write_df(t, tb, table_name="tbl_tb_control", formulas={"PeriodNum": "=VALUE(C{r})"})
    TR = lambda col: f"tb!${col}$2:${col}${n_t}"
    sc = wb.create_sheet("stdcost"); write_df(sc, std, table_name="tbl_stdcost")

    # ---------------- Variance ----------------
    v = wb.create_sheet("Variance", 1)
    title(v, "P&L variance - close month (USD, P&L sign: positive = favourable to profit)",
          "Actual = SAP GL mapped to P&L lines. Budget & Forecast = DW. Forecast excludes 'ALL' subtotal rows (D5).")
    heads = ["P&L line", "Section", "Actual", "Budget", "Var vs Budget", "Var %", "Material?", "Forecast",
             "Var vs Forecast", "Prior Year", "Var vs PY"]
    for j, h in enumerate(heads, 1): v.cell(row=4, column=j, value=h)
    style_header(v, 4, len(heads))
    first = 5
    for i, ln in enumerate(LINES, first):
        r = i
        v.cell(row=r, column=1, value=ln); v.cell(row=r, column=2, value=SECTION[ln])
        fml = {
            3: f'=SUMIFS({GLR("M")},{GLR("L")},$A{r},{GLR("B")},{YR},{GLR("K")},{PER})',
            4: f'=SUMIFS({BR("I")},{BR("D")},$A{r},{BR("G")},{YR},{BR("H")},{PER})',
            5: f"=C{r}-D{r}", 6: f'=IF(D{r}=0,"n/a",E{r}/ABS(D{r}))',
            7: f'=IF(AND(ABS(E{r})>={MABS},OR(D{r}=0,IF(D{r}=0,FALSE,ABS(E{r}/D{r})>={MPCT}))),"YES","")',
            8: f'=SUMIFS({FR("J")},{FR("D")},$A{r},{FR("H")},{YR},{FR("I")},{PER},{FR("C")},"<>ALL")',
            9: f"=C{r}-H{r}",
            10: f'=SUMIFS({GLR("M")},{GLR("L")},$A{r},{GLR("B")},{PY},{GLR("K")},{PER})',
            11: f"=C{r}-J{r}"}
        for c, fx in fml.items():
            cell = v.cell(row=r, column=c)
            if sol or r == first: cell.value = fx
            else: cell.fill = INPUT_FILL
    last = first + len(LINES) - 1
    # unmapped visibility row
    ur = last + 1
    v.cell(row=ur, column=1, value="UNMAPPED (must be 0)"); v.cell(row=ur, column=2, value="Control")
    v.cell(row=ur, column=3, value=f'=SUMIFS({GLR("M")},{GLR("L")},"UNMAPPED",{GLR("B")},{YR},{GLR("K")},{PER})')
    for c in range(1, 12): v.cell(row=ur, column=c).fill = WARN_FILL
    subs = [("Net Revenue", "1:2"), ("Gross Margin", "1:8"), ("EBIT", "1:12")]
    sub_rows = {}
    for k, (name, rng) in enumerate(subs):
        r = ur + 2 + k; sub_rows[name] = r
        a, z = [int(x) for x in rng.split(":")]
        v.cell(row=r, column=1, value=name)
        for c in [3, 4, 5, 8, 9, 10, 11]:
            col = get_column_letter(c)
            extra = f"+{col}{ur}" if (name == "EBIT" and c in (3, 5, 9, 11)) else ""
            v.cell(row=r, column=c, value=f"=SUM({col}{first + a - 1}:{col}{first + z - 1}){extra}")
        v.cell(row=r, column=6, value=f'=IF(D{r}=0,"n/a",E{r}/ABS(D{r}))')
        for c in range(1, 12):
            v.cell(row=r, column=c).fill = SUB_FILL; v.cell(row=r, column=c).font = Font(name=F, size=11, bold=True)
    # BU section
    br0 = sub_rows["EBIT"] + 3
    v.cell(row=br0 - 1, column=1, value="EBIT by business unit (profit centre)").font = Font(name=F, size=13, bold=True, color=NAVY)
    for j, h in enumerate(["Business unit", "Profit centre", "Actual EBIT", "Budget EBIT", "Var vs Budget", "Var %"], 1):
        v.cell(row=br0, column=j, value=h)
    style_header(v, br0, 6)
    for k, (pc, name) in enumerate(PCS.items(), 1):
        r = br0 + k
        v.cell(row=r, column=1, value=name); v.cell(row=r, column=2, value=int(pc))
        fx = {3: f'=SUMIFS({GLR("M")},{GLR("J")},$B{r},{GLR("B")},{YR},{GLR("K")},{PER})',
              4: f'=SUMIFS({BR("I")},{BR("C")},$B{r},{BR("G")},{YR},{BR("H")},{PER})',
              5: f"=C{r}-D{r}", 6: f'=IF(D{r}=0,"n/a",E{r}/ABS(D{r}))'}
        for c, x in fx.items():
            if sol: v.cell(row=r, column=c, value=x)
            else: v.cell(row=r, column=c).fill = INPUT_FILL
    bu_total = br0 + 5
    v.cell(row=bu_total, column=1, value="Total")
    for c in [3, 4, 5]:
        col = get_column_letter(c); v.cell(row=bu_total, column=c, value=f"=SUM({col}{br0+1}:{col}{br0+4})")
    for row in v.iter_rows(min_row=5, max_row=bu_total, min_col=3, max_col=11):
        for cell in row: cell.number_format = USD
    for r in list(range(5, bu_total + 1)): v.cell(row=r, column=6).number_format = PCT
    for col, w in zip("ABCDEFGHIJK", [26, 18, 15, 15, 15, 9, 10, 15, 15, 15, 15]): v.column_dimensions[col].width = w
    v.freeze_panes = "C5"
    EBIT_ROW, GS_ROW = sub_rows["EBIT"], first

    # ---------------- PVM ----------------
    p = wb.create_sheet("PVM", 2)
    title(p, "Gross sales: price / volume / mix vs budget - close month (product grain)",
          "Budgeted products: Price = (AP-BP)xAQ; Mix = (AQi - AQtot x BMixi) x BPi; Volume = (AQtot-BQtot) x BMixi x BPi. Products with no budget go to New products (D6). Duplicates excluded (D4).")
    ph = ["Material", "Business unit", "Budget qty MT", "Budget revenue", "Actual qty MT", "Actual revenue",
          "Budget price", "Actual price", "Budget mix", "Price var", "Mix var", "Volume var", "New products", "Total var", "Std RM cost /MT"]
    for j, h in enumerate(ph, 1): p.cell(row=4, column=j, value=h)
    style_header(p, 4, len(ph))
    pr0 = 5; prl = pr0 + len(MATERIALS) - 1; TOT = prl + 1
    bu_of = {r.Material: PCS[str(int(r.ProfitCenter))] for r in std.itertuples()}
    for i, mat in enumerate(MATERIALS):
        r = pr0 + i
        p.cell(row=r, column=1, value=mat); p.cell(row=r, column=2, value=bu_of[mat])
        data = {3: f'=SUMIFS({BSR("D")},{BSR("A")},{MON},{BSR("B")},$A{r})',
                4: f'=SUMIFS({BSR("E")},{BSR("A")},{MON},{BSR("B")},$A{r})',
                5: f'=SUMIFS({BLR("N")},{BLR("A")},{YR},{BLR("J")},{PER},{BLR("E")},$A{r})',
                6: f'=SUMIFS({BLR("O")},{BLR("A")},{YR},{BLR("J")},{PER},{BLR("E")},$A{r})',
                15: f'=INDEX(stdcost!$E$2:$E$20,MATCH($A{r},stdcost!$A$2:$A$20,0))'}
        calc = {7: f'=IF(C{r}>0,D{r}/C{r},0)', 8: f'=IF(E{r}>0,F{r}/E{r},0)',
                9: f'=IF(C{r}>0,C{r}/$C${TOT},0)',
                10: f'=IF(AND(C{r}>0,E{r}>0),(H{r}-G{r})*E{r},0)',
                11: f'=IF(C{r}>0,(E{r}-$P${TOT}*I{r})*G{r},0)',
                12: f'=IF(C{r}>0,($P${TOT}-$C${TOT})*I{r}*G{r},0)',
                13: f'=IF(C{r}=0,F{r},0)', 14: f'=F{r}-D{r}'}
        for c, x in data.items(): p.cell(row=r, column=c, value=x)
        for c, x in calc.items():
            if sol or i == 0: p.cell(row=r, column=c, value=x)
            else: p.cell(row=r, column=c).fill = INPUT_FILL
    p.cell(row=TOT, column=1, value="Total")
    for c in [3, 4, 5, 6, 10, 11, 12, 13, 14]:
        col = get_column_letter(c); p.cell(row=TOT, column=c, value=f"=SUM({col}{pr0}:{col}{prl})")
    p.cell(row=4, column=16, value="AQ budgeted products"); style_header(p, 4, 1, start=16)
    p.cell(row=TOT, column=16, value=f'=SUMIFS(E{pr0}:E{prl},C{pr0}:C{prl},">0")')
    for c in range(1, 17):
        p.cell(row=TOT, column=c).fill = SUB_FILL; p.cell(row=TOT, column=c).font = Font(name=F, size=11, bold=True)
    p.cell(row=TOT + 2, column=1, value="Check: Price+Mix+Volume+New - Total (must be 0)")
    p.cell(row=TOT + 2, column=14, value=f"=ROUND(J{TOT}+K{TOT}+L{TOT}+M{TOT}-N{TOT},2)")
    p.cell(row=TOT + 3, column=1, value="Check: PVM total - Variance!Gross Sales var (must be 0)")
    p.cell(row=TOT + 3, column=14, value=f"=ROUND(N{TOT}-Variance!E{GS_ROW},2)")
    for row in p.iter_rows(min_row=pr0, max_row=TOT + 3, min_col=3, max_col=16):
        for cell in row: cell.number_format = USD
    for r in range(pr0, TOT + 1):
        p.cell(row=r, column=9).number_format = "0.0%"
        for c in (3, 5, 16): p.cell(row=r, column=c).number_format = "#,##0.0"
    for j in range(1, 17): p.column_dimensions[get_column_letter(j)].width = 14
    p.column_dimensions["B"].width = 20
    PVM_CHECK = f"PVM!N{TOT + 2}"; PVM_TIE = f"PVM!N{TOT + 3}"

    # ---------------- Drivers ----------------
    dr = wb.create_sheet("Drivers", 3)
    title(dr, "Cost driver analysis - close month", "Freight: volume effect at budget rate vs rate effect at actual shipments; expedited freight shown separately (D1/D8). Raw materials: standard cost on actual volume isolates the siloxane price effect.")
    fh = ["Entity", "Budget freight", "Actual std freight (540000)", "Expedited (540050)", "Budget shipments",
          "Actual shipments", "Budget rate", "Actual rate", "Volume effect", "Rate effect", "Expedited effect", "Total variance"]
    for j, h in enumerate(fh, 1): dr.cell(row=4, column=j, value=h)
    style_header(dr, 4, len(fh))
    for k, ent in enumerate(ENTITIES):
        r = 5 + k
        dr.cell(row=r, column=1, value=ent)
        fx = {2: f'=SUMIFS({BR("F")},{BR("B")},$A{r},{BR("D")},"Freight Outbound",{BR("A")},{MON})',
              3: f'=-SUMIFS({GLR("M")},{GLR("A")},$A{r},{GLR("I")},540000,{GLR("B")},{YR},{GLR("K")},{PER})',
              4: f'=-SUMIFS({GLR("M")},{GLR("A")},$A{r},{GLR("I")},540050,{GLR("B")},{YR},{GLR("K")},{PER})',
              5: f'=SUMIFS({OR_("E")},{OR_("A")},{MON},{OR_("B")},$A{r},{OR_("C")},"Budget")',
              6: f'=SUMIFS({OR_("E")},{OR_("A")},{MON},{OR_("B")},$A{r},{OR_("C")},"Actual")',
              7: f"=IF(E{r}=0,0,B{r}/E{r})", 8: f"=IF(F{r}=0,0,C{r}/F{r})",
              9: f"=-(F{r}-E{r})*G{r}", 10: f"=-(H{r}-G{r})*F{r}", 11: f"=-D{r}", 12: f"=I{r}+J{r}+K{r}"}
        for c, x in fx.items():
            if sol or k == 0 or c <= 6: dr.cell(row=r, column=c, value=x)
            else: dr.cell(row=r, column=c).fill = INPUT_FILL
    dr.cell(row=8, column=1, value="Total")
    for c in [2, 3, 4, 9, 10, 11, 12]:
        col = get_column_letter(c); dr.cell(row=8, column=c, value=f"=SUM({col}5:{col}7)")
    dr["A9"] = "Sign: effects use P&L sign (negative = adverse). Total freight variance should equal Variance!E for Freight Outbound."
    fr_row = 5 + LINES.index("Freight Outbound")
    dr["A10"] = "Check: Drivers total - Variance freight var (must be 0)"; dr["L10"] = f"=ROUND(L8-Variance!E{fr_row},2)"
    dr["A13"] = "Raw materials"; dr["A13"].font = Font(name=F, size=13, bold=True, color=NAVY)
    rmh = ["Measure", "USD (P&L sign)", "How it is calculated"]
    for j, h in enumerate(rmh, 1): dr.cell(row=14, column=j, value=h)
    style_header(dr, 14, 3)
    rm_row = 5 + LINES.index("Raw Materials")
    rm = [("Actual raw materials", f"=Variance!C{rm_row}", "SAP GL 500000+500100"),
          ("Budget raw materials", f"=Variance!D{rm_row}", "DW budget"),
          ("Standard cost on actual volume", f"=-SUMPRODUCT(PVM!E{pr0}:E{prl},PVM!O{pr0}:O{prl})", "Actual qty x SAP standard RM cost/MT"),
          ("Volume / mix effect", "=B17-B16", "Std on actual volume - budget"),
          ("Rate (siloxane price) effect", "=B15-B17", "Actual - std on actual volume"),
          ("Check: effects - total RM variance (must be 0)", f"=ROUND(B18+B19-Variance!E{rm_row},2)", "")]
    for k, (a, bx, cx) in enumerate(rm):
        r = 15 + k; dr.cell(row=r, column=1, value=a); dr.cell(row=r, column=3, value=cx)
        if sol or k < 3 or k == 5: dr.cell(row=r, column=2, value=bx)
        else: dr.cell(row=r, column=2).fill = INPUT_FILL
    for row in dr.iter_rows(min_row=5, max_row=20, min_col=2, max_col=12):
        for cell in row: cell.number_format = USD
    for j, w in enumerate([34, 16, 18, 16, 14, 14, 12, 12, 14, 14, 14, 14], 1): dr.column_dimensions[get_column_letter(j)].width = w
    FR_CHECK, RM_CHECK = "Drivers!L10", "Drivers!B20"

    # ---------------- Checks ----------------
    ch = wb.create_sheet("Checks", 1)
    title(ch, "Reconciliation checks - every line must be PASS (or EXPLAINED) before analysis starts",
          "Each check maps to a planted defect. Copilot never replaces these checks.")
    chh = ["#", "Check", "Value", "Expected", "Status", "Defect", "What to do if it fails"]
    for j, h in enumerate(chh, 1): ch.cell(row=4, column=j, value=h)
    style_header(ch, 4, len(chh))
    def status(r, kind="zero"):
        if kind == "zero": return f'=IF(ABS(C{r})<={TOL},"PASS","FAIL")'
    checks = [
        ("C1", "Unmapped GL rows in close period", f'=COUNTIFS({GLR("L")},"UNMAPPED",{GLR("B")},{YR},{GLR("K")},{PER})', 0, "D1", "Add the missing GL account(s) to map (tbl_map). Ask the GL owner which P&L line."),
        ("C2", "Unmapped amount in close period", f"=Variance!C{ur}", 0, "D1", "Same as C1."),
        ("C3", "GL net vs TB control - US10", f'=SUMIFS({GLR("M")},{GLR("A")},"US10",{GLR("B")},{YR},{GLR("K")},{PER})-SUMIFS({TR("D")},{TR("A")},"US10",{TR("B")},{YR},{TR("F")},{PER})', 0, "D10", "Re-extract or document a timing difference."),
        ("C4", "GL net vs TB control - DE20", f'=SUMIFS({GLR("M")},{GLR("A")},"DE20",{GLR("B")},{YR},{GLR("K")},{PER})-SUMIFS({TR("D")},{TR("A")},"DE20",{TR("B")},{YR},{TR("F")},{PER})', 0, "D10", "Re-extract or document a timing difference."),
        ("C5", "GL net vs TB control - IN30", f'=SUMIFS({GLR("M")},{GLR("A")},"IN30",{GLR("B")},{YR},{GLR("K")},{PER})-SUMIFS({TR("D")},{TR("A")},"IN30",{TR("B")},{YR},{TR("F")},{PER})', 0, "D10", "Expected FAIL by -85,000: accrual reversal posted after the extract. Capstone: swap in the re-extract and refresh."),
        ("C6", "Duplicate billing rows in close period", f'=SUMIFS({BLR("M")},{BLR("A")},{YR},{BLR("J")},{PER})', 0, "D4", "Exclude rows where IsDuplicate=1 (RevClean/QtyClean columns)."),
        ("C7", "Billing revenue (clean) - GL Gross Sales", f'=SUMIFS({BLR("O")},{BLR("A")},{YR},{BLR("J")},{PER})-Variance!C{GS_ROW}', 0, "D4", "If not 0 after de-duplication, the billing and GL extracts are from different run times."),
        ("C8", "Forecast 'ALL' subtotal rows in close month", f'=COUNTIFS({FR("C")},"ALL",{FR("H")},{YR},{FR("I")},{PER})', "info", "D5", "Never sum the forecast without excluding ProfitCenter = ALL (Variance formulas use \"<>ALL\")."),
        ("C9", "PVM components - total (must be 0)", f"={PVM_CHECK}", 0, "D6", "New products must sit in their own bucket; check the PVM formulas."),
        ("C10", "PVM total - Gross Sales variance", f"={PVM_TIE}", 0, "D4/D6", "Usually duplicates still in billing, or wrong month key."),
        ("C11", "Freight drivers - freight variance", f"={FR_CHECK}", 0, "D1/D8", "Expedited freight must be mapped (C1) and shown separately."),
        ("C12", "RM rate + volume - RM variance", f"={RM_CHECK}", 0, "-", "Check the standard cost lookup."),
        ("C13", "EBIT (Variance) - total GL net, close period", f'=Variance!C{EBIT_ROW}-SUMIFS({GLR("M")},{GLR("B")},{YR},{GLR("K")},{PER})', 0, "D1/D2", "Unmapped rows or a sign flip."),
    ]
    for k, (cid, desc, fx, exp, dfx, todo) in enumerate(checks):
        r = 5 + k
        vals = [cid, desc, None, exp, None, dfx, todo]
        for j, x in enumerate(vals, 1):
            if x is not None: ch.cell(row=r, column=j, value=x)
        if sol or k == 0:
            ch.cell(row=r, column=3, value=fx)
            if exp == "info":
                ch.cell(row=r, column=5, value=f'=IF(C{r}>0,"TRAP PRESENT - handled","PASS")')
            elif cid == "C6":
                ch.cell(row=r, column=5, value=f'=IF(C{r}=0,"PASS",IF(ABS(C{r+1})<={TOL},"HANDLED - excluded via RevClean","FAIL"))')
            elif cid == "C5":
                ch.cell(row=r, column=5, value=f'=IF(ABS(C{r})<={TOL},"PASS",IF(ABS(C{r}+85000)<={TOL},"EXPLAINED (D10 timing)","FAIL"))')
            else:
                ch.cell(row=r, column=5, value=status(r))
        else:
            ch.cell(row=r, column=3).fill = INPUT_FILL; ch.cell(row=r, column=5).fill = INPUT_FILL
        ch.cell(row=r, column=3).number_format = USD
    lastc = 5 + len(checks) - 1
    ch.cell(row=lastc + 2, column=2, value="Overall status")
    ch.cell(row=lastc + 2, column=5, value=f'=IF(COUNTIF(E5:E{lastc},"FAIL")+COUNTBLANK(E5:E{lastc})=0,"READY FOR ANALYSIS","NOT READY")')
    ch.cell(row=lastc + 2, column=5).font = Font(name=F, size=11, bold=True)
    for col, w in zip("ABCDEFG", [6, 44, 16, 10, 24, 9, 60]): ch.column_dimensions[col].width = w

    # ---------------- Commentary ----------------
    cm = wb.create_sheet("Commentary", 4)
    title(cm, "Variance commentary - Copilot drafts, analyst finalises",
          "Paste the =COPILOT() or Copilot pane draft in column D. Column E is the only text that leaves the team. Every figure in E must tie to the Variance sheet.")
    cmh = ["P&L line", "Var vs Budget", "Driver evidence (sheet/cell)", "Copilot draft (not for distribution)", "Analyst final commentary", "Reviewer", "Status"]
    for j, h in enumerate(cmh, 1): cm.cell(row=4, column=j, value=h)
    style_header(cm, 4, len(cmh))
    K = KEY
    finals = {
        "Gross Sales": ("PVM!J:N; Variance!E5",
                        f"Gross sales {K['variance_table'][0]['Var_vs_Budget']/1e6:+.2f}M vs budget ({K['variance_table'][0]['VarPct_vs_Budget']:.1f}%). New Low-VOC fluid SF-405 added {K['pvm_total']['NewProducts']/1e6:.2f}M with no budget; price +{K['pvm_total']['Price']/1e6:.2f}M (Sealants list-price increase); volume +{K['pvm_total']['Volume']/1e6:.2f}M; offset by adverse mix {K['pvm_total']['Mix']/1e6:.2f}M as Sealants volume shifted from SA-240 glazing adhesive to lower-priced SA-120 construction sealant."),
        "Raw Materials": ("Drivers!B15:B19",
                          f"Raw materials {K['variance_table'][2]['Var_vs_Budget']/1e6:.2f}M adverse. Rate (siloxane) effect {K['raw_materials']['RateEffect']/1e6:.2f}M; volume/mix effect {K['raw_materials']['VolumeMixEffect']/1e6:.2f}M from higher volumes. Siloxane cost inflation is the single largest adverse driver this month."),
        "Freight Outbound": ("Drivers!A5:L8",
                             f"Freight {K['variance_table'][6]['Var_vs_Budget']/1e3:,.0f}k adverse. DE20 expedited freight {K['freight']['DE20']['Expedited']/1e3:,.0f}k on new GL 540050; DE20 carrier rate up {K['freight']['DE20']['ActualRate']/K['freight']['DE20']['BudgetRate']*100-100:.0f}% ({K['freight']['DE20']['RateEffect']/1e3:,.0f}k); US10 volume-driven {K['freight']['US10']['VolumeEffect']/1e3:,.0f}k."),
        "Inventory Adjustments": ("gl: GL 545000, US10, PC 1300",
                                  "One-off inventory write-off of 1.20M at US10 Elastomers (GL 545000), not budgeted. Confirm root cause with the plant controller before release; exclude from run-rate."),
    }
    for k, ln in enumerate(K["material_lines_incl_no_budget"]):
        r = 5 + k; vr = 5 + LINES.index(ln)
        cm.cell(row=r, column=1, value=ln); cm.cell(row=r, column=2, value=f"=Variance!E{vr}").number_format = USD
        if sol:
            ev, txt = finals[ln]
            cm.cell(row=r, column=3, value=ev)
            cm.cell(row=r, column=4, value="(example) paste Copilot draft here")
            cm.cell(row=r, column=5, value=txt); cm.cell(row=r, column=6, value="FP&A manager"); cm.cell(row=r, column=7, value="Worked example")
        else:
            for c in (3, 4, 5, 6, 7): cm.cell(row=r, column=c).fill = INPUT_FILL
    for col, w in zip("ABCDEFG", [22, 15, 26, 40, 70, 14, 14]): cm.column_dimensions[col].width = w

    # ---------------- Answer key (solution only) ----------------
    if sol:
        ak = wb.create_sheet("AnswerKey")
        title(ak, "FACILITATOR ANSWER KEY - remove this sheet before giving the workbook to participants",
              "Expected values were computed independently in Python (gen_data.py). 'Model' links to this workbook; Diff must be 0.")
        akh = ["Item", "Expected (Python)", "Model (Excel)", "Diff"]
        for j, h in enumerate(akh, 1): ak.cell(row=4, column=j, value=h)
        style_header(ak, 4, 4)
        items = [(f"{ln} - Var vs Budget", K["variance_table"][i]["Var_vs_Budget"], f"=Variance!E{5+i}") for i, ln in enumerate(LINES)]
        items += [("EBIT actual", K["subtotals"]["EBIT"]["Actual"], f"=Variance!C{EBIT_ROW}"),
                  ("EBIT budget", K["subtotals"]["EBIT"]["Budget"], f"=Variance!D{EBIT_ROW}"),
                  ("EBIT var vs budget", K["subtotals"]["EBIT"]["Var_vs_Budget"], f"=Variance!E{EBIT_ROW}"),
                  ("EBIT forecast", K["subtotals"]["EBIT"]["Forecast"], f"=Variance!H{EBIT_ROW}"),
                  ("EBIT prior year", K["subtotals"]["EBIT"]["PriorYear"], f"=Variance!J{EBIT_ROW}")]
        for k, (pc, name) in enumerate(PCS.items(), 1):
            items.append((f"EBIT var - {name}", K["ebit_by_bu"][name]["Var"], f"=Variance!E{br0+k}"))
        for comp, col in [("Price", "J"), ("Mix", "K"), ("Volume", "L"), ("NewProducts", "M"), ("Total", "N")]:
            items.append((f"PVM {comp}", K["pvm_total"][comp], f"=PVM!{col}{TOT}"))
        items += [("RM rate effect", K["raw_materials"]["RateEffect"], "=Drivers!B19"),
                  ("RM volume/mix effect", K["raw_materials"]["VolumeMixEffect"], "=Drivers!B18"),
                  ("DE20 freight rate effect", -K["freight"]["DE20"]["RateEffect"], "=Drivers!J6"),
                  ("DE20 expedited", -K["freight"]["DE20"]["Expedited"], "=Drivers!K6"),
                  ("US10 freight volume effect", -K["freight"]["US10"]["VolumeEffect"], "=Drivers!I5"),
                  ("C5 IN30 TB difference (D10)", -K["checks"]["D10_IN30_sep_difference"], "=Checks!C9"),
                  ("C6 duplicate rows (D4)", K["checks"]["D4_duplicate_rows"], "=Checks!C10"),
                  ("C8 forecast ALL rows in month (D5)", 36, "=Checks!C12")]
        for k, (a, e, fx) in enumerate(items):
            r = 5 + k
            ak.cell(row=r, column=1, value=a); ak.cell(row=r, column=2, value=e); ak.cell(row=r, column=3, value=fx)
            ak.cell(row=r, column=4, value=f"=ROUND(C{r}-B{r},0)")
            for c in (2, 3, 4): ak.cell(row=r, column=c).number_format = USD
        lr = 5 + len(items)
        ak.cell(row=lr + 1, column=1, value="Rows with non-zero diff"); ak.cell(row=lr + 1, column=4, value=f'=COUNTIF(D5:D{lr-1},"<>0")')
        for col, w in zip("ABCD", [40, 18, 18, 10]): ak.column_dimensions[col].width = w

    # ---------------- README ----------------
    rd = wb["README"]
    title(rd, f"Momentive FP&A Variance Model - {mode}", "FICTIONAL TEACHING DATA. Plants, products, customers and all figures are invented for training. Not Momentive data.")
    lines = [
        ("Close month", "September 2026 (FY2026 period 009). Change Inputs!B4:B5 to re-run for another month."),
        ("Sign convention", "P&L sign throughout: positive = favourable to profit. SAP credits are negative, so gl!PLAmount = -AmountUSD. DW stores costs as positive, so bud/fc PLAmount flips costs (D2)."),
        ("Variance", "Actual vs Budget, Forecast (6+6) and Prior Year by P&L line, subtotals, EBIT by business unit."),
        ("Checks", "13 reconciliation checks mapped to planted defects D1-D10. Run before any Copilot analysis."),
        ("PVM", "Price / volume / mix of gross sales at product grain, with new products separated."),
        ("Drivers", "Freight volume vs rate vs expedited; raw-material rate vs volume using SAP standard cost."),
        ("Commentary", "Copilot draft column and analyst final column. Only the final column is distributed."),
        ("Data sheets", "gl, bud, fc, bill, bsales, ops, tb, stdcost, map - loaded unchanged from the CSV extracts, with helper formula columns on the right."),
        ("Copilot tip", "Copilot in Excel works on formatted Tables; every data sheet is an Excel Table (tbl_*). Use Copilot in Chat-only mode on this controlled workbook."),
    ]
    if not sol:
        lines.insert(0, ("How to use (STARTER)", "Yellow cells are yours to complete. Row 1 of each block shows a worked formula; copy the pattern. The map sheet is deliberately missing one account (find it in Lab 2)."))
    else:
        lines.insert(0, ("How to use (SOLUTION)", "Facilitator copy. The AnswerKey sheet compares every result with independently computed Python values. Remove AnswerKey before sharing."))
    for k, (a, bx) in enumerate(lines, 4):
        rd.cell(row=k, column=1, value=a).font = Font(name=F, size=11, bold=True); rd.cell(row=k, column=2, value=bx)
    rd.column_dimensions["A"].width = 24; rd.column_dimensions["B"].width = 110

    # ---------------- global font / wrap post-pass ----------------
    for wsx in wb.worksheets:
        for row in wsx.iter_rows():
            for cell in row:
                fnt = cell.font
                cell.font = Font(name=F, size=fnt.size if (fnt and fnt.size and fnt.size > 11 and cell.row <= 2) else 11,
                                 bold=fnt.b, italic=fnt.i, color=fnt.color)
                al = cell.alignment
                cell.alignment = Alignment(wrap_text=True, horizontal=al.horizontal, vertical=al.vertical or "top")
        if wsx.title in ("gl", "bud", "fc", "bill", "bsales", "ops", "tb", "stdcost", "map"):
            for j in range(1, wsx.max_column + 1): wsx.column_dimensions[get_column_letter(j)].width = 15
    path = os.path.join(OUTDIR, f"Momentive_Variance_Model_{mode}.xlsx")
    wb.save(path); print("saved", path)
    return path


if __name__ == "__main__":
    for mode in sys.argv[1:] or ["SOLUTION", "STARTER"]:
        build(mode)
