"""
Momentive FP&A Copilot Lab Kit - synthetic data generator (single source of truth).
ALL DATA IS FICTIONAL TEACHING DATA. Plant names, figures, products are invented.

Outputs (kit/03_Sample_Data):
  SAP_Extracts/SAP_GL_Actuals_FY2025_FY2026.csv
  SAP_Extracts/SAP_Billing_Sales_FY2025_FY2026.csv
  SAP_Extracts/SAP_TrialBalance_Control.csv
  SAP_Extracts/SAP_GL_Actuals_Sep2026_REEXTRACT.csv   (capstone)
  DW_Extracts/DW_Budget_PL_FY2026.csv
  DW_Extracts/DW_Budget_Sales_FY2026.csv
  DW_Extracts/DW_Forecast_6plus6_FY2026.csv
  DW_Extracts/DW_Ops_Volumes_FY2026.csv
  Reference/GL_to_PL_Mapping.csv  (also written as xlsx by build_workbooks.py)
and build/answer_key.json
"""
import json, math, os
import numpy as np
import pandas as pd

rng = np.random.default_rng(20261012)
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "kit", "03_Sample_Data")
for d in ["SAP_Extracts", "DW_Extracts", "Reference"]:
    os.makedirs(os.path.join(OUT, d), exist_ok=True)

CLOSE_YEAR, CLOSE_P = 2026, 9

COMPANIES = {
    "US10": "Riverbend Plant (US) - fictional",
    "DE20": "Rheinfeld Plant (DE) - fictional",
    "IN30": "Bengaluru Tech & Ops (IN) - fictional",
}
PCS = {"1100": "Specialty Fluids", "1200": "Sealants & Adhesives",
       "1300": "Elastomers", "1400": "Coatings & Additives"}

# material, desc, pc, company, segments, budget price/MT, base qty MT/month per segment, rm share, launch period
PRODUCTS = [
    ("SF-101", "Silicone Fluid 350cSt",        "1100", "US10", ["Personal Care", "Industrial"], 4200, 420, 0.46, None),
    ("SF-205", "Amino-functional Fluid",       "1100", "DE20", ["Personal Care", "Industrial"], 6800, 210, 0.44, None),
    ("SF-310", "Silicone Emulsion Base",       "1100", "IN30", ["Personal Care", "Industrial"], 3600, 300, 0.47, None),
    ("SF-405", "Low-VOC Fluid (launched Jun-26)", "1100", "US10", ["Personal Care", "Electronics"], None, 0, 0.42, 6),
    ("SA-120", "Construction Sealant",         "1200", "US10", ["Construction", "Industrial"], 3900, 520, 0.45, None),
    ("SA-240", "Structural Glazing Adhesive",  "1200", "DE20", ["Construction", "Electronics"], 9800, 240, 0.43, None),
    ("SA-360", "Automotive Bonding Adhesive",  "1200", "US10", ["Automotive", "Industrial"], 8600, 180, 0.44, None),
    ("EL-150", "HCR Rubber Compound",          "1300", "US10", ["Automotive", "Industrial"], 5200, 360, 0.47, None),
    ("EL-250", "LSR Medical Grade",            "1300", "DE20", ["Healthcare", "Electronics"], 12400, 110, 0.40, None),
    ("EL-350", "FSR Compound",                 "1300", "IN30", ["Automotive", "Industrial"], 7400, 130, 0.45, None),
    ("CA-110", "Paint Additive",               "1400", "DE20", ["Construction", "Industrial"], 5600, 230, 0.45, None),
    ("CA-220", "Release Coating",              "1400", "US10", ["Industrial", "Electronics"], 7200, 190, 0.44, None),
    ("CA-330", "Hardcoat Resin",               "1400", "IN30", ["Electronics", "Automotive"], 10200, 90, 0.43, None),
]
SF405_PRICE = 7900  # actual price of new product
SF405_QTY = {6: 54, 7: 99, 8: 144, 9: 198}  # per segment, MT

# Actual vs budget drivers (FY2026) - the designed "story" for the Sep close
QTY_FACTOR = {"SF-101": 1.06, "SF-205": 1.05, "SF-310": 1.07, "SA-120": 1.15, "SA-240": 0.82, "SA-360": 0.97,
              "EL-150": 0.90, "EL-250": 0.94, "EL-350": 0.92, "CA-110": 1.01, "CA-220": 0.99, "CA-330": 1.02}
PRICE_FACTOR = {"SF-101": 1.02, "SF-205": 1.02, "SF-310": 1.02, "SA-120": 1.04, "SA-240": 1.04, "SA-360": 1.04,
                "EL-150": 1.00, "EL-250": 1.00, "EL-350": 1.00, "CA-110": 1.005, "CA-220": 0.995, "CA-330": 1.0}

def season(p):  # period 1..12
    return 1 + 0.08 * math.sin(2 * math.pi * (p - 3) / 12)

# ----------------------------- SALES (billing) ------------------------------
bill_rows, bud_sales_rows = [], []
for mat, desc, pc, cc, segs, bprice, bqty, rm, launch in PRODUCTS:
    for p in range(1, 13):
        for s in segs:
            if bprice is not None:
                bq = round(bqty * 1.8 * season(p) * (1.0 if s == segs[0] else 0.6), 1)
                brev = round(bq * bprice)
                bud_sales_rows.append(dict(Month=f"2026-{p:02d}", Material=mat, CustomerSegment=s,
                                           BudgetQtyMT=bq, BudgetRevenueUSD=brev,
                                           BudgetPriceUSDperMT=round(brev / bq, 2)))
    for fy, plast in [(2025, 12), (2026, CLOSE_P)]:
        for p in range(1, plast + 1):
            for s in segs:
                if bprice is None:
                    if fy == 2026 and p >= launch:
                        q = SF405_QTY[p] * (1.0 if s == segs[0] else 0.5)
                        price = SF405_PRICE
                    else:
                        continue
                else:
                    base = bqty * 1.8 * season(p) * (1.0 if s == segs[0] else 0.6)
                    noise = rng.normal(1, 0.015)
                    if fy == 2026:
                        q = base * QTY_FACTOR[mat] * noise
                        price = bprice * PRICE_FACTOR[mat] * rng.normal(1, 0.004)
                    else:
                        q = base * 0.95 * noise
                        price = bprice * 0.97 * rng.normal(1, 0.004)
                q = round(q, 1)
                bill_rows.append(dict(FiscalYear=fy, Period=f"{p:03d}", CompanyCode=cc,
                                      ProfitCenter=f"{int(pc):010d}", Material=mat, MaterialDesc=desc,
                                      CustomerSegment=s, BilledQtyMT=q, NetRevenueUSD=round(q * price)))
billing = pd.DataFrame(bill_rows)
bud_sales = pd.DataFrame(bud_sales_rows)

# ----------------------------- COST MODEL ----------------------------------
FIXED = {  # monthly budget USD by company
    "US10": dict(labour=1_900_000, overhead=800_000, selling=1_100_000, rnd=900_000, ga=1_200_000, dep=1_400_000),
    "DE20": dict(labour=1_600_000, overhead=600_000, selling=800_000, rnd=500_000, ga=700_000, dep=1_000_000),
    "IN30": dict(labour=450_000, overhead=150_000, selling=250_000, rnd=600_000, ga=350_000, dep=200_000),
}
FREIGHT_RATE = {"US10": 1800, "DE20": 2100, "IN30": 900}
MT_PER_SHIPMENT = 18
ENERGY_PER_MT = {"US10": 240, "DE20": 330, "IN30": 180}

prod_df = pd.DataFrame([dict(Material=x[0], PC=x[2], CC=x[3], RM=x[7], BPrice=x[5] or SF405_PRICE) for x in PRODUCTS])

# PC shares within company from annual budget revenue
bud_rev_pc = bud_sales.merge(prod_df, on="Material").groupby(["CC", "PC"])["BudgetRevenueUSD"].sum()
PC_SHARE = {cc: (bud_rev_pc[cc] / bud_rev_pc[cc].sum()).to_dict() for cc in COMPANIES}

def rm_index(fy, p):
    if fy == 2025: return 0.96
    return 1.0 if p < 7 else {7: 1.04, 8: 1.05, 9: 1.07}[p]

def energy_index(fy, p, cc):
    if fy == 2025: return 0.97
    return 1.10 if cc == "DE20" and p >= 4 else 1.0

def freight_rate(fy, p, cc):
    if fy == 2025: return FREIGHT_RATE[cc] * 0.96
    if cc == "DE20" and p == 9: return FREIGHT_RATE[cc] * 1.28   # D8 rate spike
    if cc == "DE20" and p in (7, 8): return FREIGHT_RATE[cc] * 1.06
    return FREIGHT_RATE[cc]

def fixed_factor(fy, p, kind):
    if fy == 2025: return 0.96
    return {"labour": 1.01, "overhead": 1.03, "selling": 0.98, "rnd": 1.00, "ga": 1.02, "dep": 1.00}[kind] * rng.normal(1, 0.01)

GL = {  # account: description
    "400000": "Sales revenue - domestic", "400100": "Sales revenue - export",
    "410000": "Customer rebates", "410100": "Cash discounts",
    "500000": "Raw material consumption - siloxane", "500100": "Raw material - fillers & additives",
    "510000": "Energy - natural gas", "510100": "Energy - electricity",
    "520000": "Direct wages", "530000": "Plant maintenance", "530100": "Plant supplies",
    "540000": "Outbound freight", "540050": "Freight - expedited (opened Jul-26)",
    "545000": "Inventory write-off", "600000": "Sales salaries", "600100": "Sales travel",
    "610000": "R&D salaries", "610100": "Lab consumables", "620000": "G&A salaries",
    "620100": "IT & software", "620200": "Professional fees", "700000": "Depreciation",
}
MAPPING = [  # GL, PL line, section, line order, line type  (540050 intentionally missing: D1)
    ("400000", "Gross Sales", "Revenue", 1, "Revenue"), ("400100", "Gross Sales", "Revenue", 1, "Revenue"),
    ("410000", "Rebates & Discounts", "Revenue", 2, "Cost"), ("410100", "Rebates & Discounts", "Revenue", 2, "Cost"),
    ("500000", "Raw Materials", "Cost of Sales", 3, "Cost"), ("500100", "Raw Materials", "Cost of Sales", 3, "Cost"),
    ("510000", "Energy", "Cost of Sales", 4, "Cost"), ("510100", "Energy", "Cost of Sales", 4, "Cost"),
    ("520000", "Direct Labour", "Cost of Sales", 5, "Cost"),
    ("530000", "Plant Overhead", "Cost of Sales", 6, "Cost"), ("530100", "Plant Overhead", "Cost of Sales", 6, "Cost"),
    ("540000", "Freight Outbound", "Cost of Sales", 7, "Cost"),
    ("545000", "Inventory Adjustments", "Cost of Sales", 8, "Cost"),
    ("600000", "Selling", "Operating Expenses", 9, "Cost"), ("600100", "Selling", "Operating Expenses", 9, "Cost"),
    ("610000", "R&D", "Operating Expenses", 10, "Cost"), ("610100", "R&D", "Operating Expenses", 10, "Cost"),
    ("620000", "G&A", "Operating Expenses", 11, "Cost"), ("620100", "G&A", "Operating Expenses", 11, "Cost"),
    ("620200", "G&A", "Operating Expenses", 11, "Cost"),
    ("700000", "Depreciation", "Operating Expenses", 12, "Cost"),
]
PL_LINES = ["Gross Sales", "Rebates & Discounts", "Raw Materials", "Energy", "Direct Labour", "Plant Overhead",
            "Freight Outbound", "Inventory Adjustments", "Selling", "R&D", "G&A", "Depreciation"]
LINE_TYPE = {m[1]: m[4] for m in MAPPING}

gl_rows = []
def post(fy, p, cc, pc, ccenter, acct, amt_sap):
    gl_rows.append(dict(CompanyCode=cc, FiscalYear=fy, Period=f"{p:03d}", ProfitCenter=f"{int(pc):010d}",
                        CostCenter=ccenter, GLAccount=f"{int(acct):010d}", GLDescription=GL[acct],
                        AmountUSD=round(amt_sap, 2)))

ops_rows = []
for fy, plast in [(2025, 12), (2026, CLOSE_P)]:
    for p in range(1, plast + 1):
        b = billing[(billing.FiscalYear == fy) & (billing.Period == f"{p:03d}")].merge(
            prod_df, on="Material")
        for cc in COMPANIES:
            bc = b[b.CompanyCode == cc]
            ship_total = 0
            for pc in PCS:
                bp = bc[bc.PC == pc]
                if bp.empty: continue
                rev = bp.NetRevenueUSD.sum(); qty = bp.BilledQtyMT.sum()
                dom = 0.7 if cc == "US10" else (0.45 if cc == "DE20" else 0.6)
                post(fy, p, cc, pc, f"{cc}-SALES", "400000", -round(rev * dom))
                post(fy, p, cc, pc, f"{cc}-SALES", "400100", -(rev - round(rev * dom)))
                reb = 0.032 if (fy == 2026 and pc == "1200") else 0.03
                post(fy, p, cc, pc, f"{cc}-SALES", "410000", rev * reb)
                post(fy, p, cc, pc, f"{cc}-SALES", "410100", rev * 0.008)
                rm_cost = (bp.BilledQtyMT * bp.BPrice * bp.RM).sum() * rm_index(fy, p)
                post(fy, p, cc, pc, f"{cc}-PLANT", "500000", rm_cost * 0.8)
                post(fy, p, cc, pc, f"{cc}-PLANT", "500100", rm_cost * 0.2)
                en = qty * ENERGY_PER_MT[cc] * energy_index(fy, p, cc)
                post(fy, p, cc, pc, f"{cc}-PLANT", "510000", en * 0.55)
                post(fy, p, cc, pc, f"{cc}-PLANT", "510100", en * 0.45)
                ships = math.ceil(qty / MT_PER_SHIPMENT); ship_total += ships
                post(fy, p, cc, pc, f"{cc}-LOGI", "540000", ships * freight_rate(fy, p, cc))
                sh = PC_SHARE[cc][pc]
                for kind, accts, ccen in [("labour", [("520000", 1.0)], "PLANT"),
                                          ("overhead", [("530000", 0.7), ("530100", 0.3)], "PLANT"),
                                          ("selling", [("600000", 0.85), ("600100", 0.15)], "SEL"),
                                          ("rnd", [("610000", 0.8), ("610100", 0.2)], "RND"),
                                          ("ga", [("620000", 0.6), ("620100", 0.25), ("620200", 0.15)], "GA"),
                                          ("dep", [("700000", 1.0)], "FIN")]:
                    amt = FIXED[cc][kind] * fixed_factor(fy, p, kind) * sh
                    for a, w in accts:
                        post(fy, p, cc, pc, f"{cc}-{ccen}", a, amt * w)
            # D1 expedited freight on a new unmapped account
            if fy == 2026 and cc == "DE20" and p in (7, 8, 9):
                exp = {7: 60_000, 8: 95_000, 9: 210_000}[p]
                done = 0.0
                for i, pc in enumerate(["1100", "1200", "1300", "1400"]):
                    part = exp - done if i == 3 else round(exp * PC_SHARE[cc][pc], 2)
                    done += part
                    post(fy, p, cc, pc, f"{cc}-LOGI", "540050", part)
            # D7 one-off inventory write-off
            if fy == 2026 and cc == "US10" and p == 9:
                post(fy, p, cc, "1300", f"{cc}-PLANT", "545000", 1_200_000)
            hc = {"US10": 640, "DE20": 410, "IN30": 230}[cc] * (1.0 if fy == 2026 else 0.97)
            ops_rows.append(dict(Month=f"{fy}-{p:02d}", Entity=cc, Scenario="Actual",
                                 ShippedMT=round(bc.BilledQtyMT.sum(), 1), Shipments=ship_total,
                                 ProductionMT=round(bc.BilledQtyMT.sum() * rng.normal(1.02, 0.01), 1),
                                 Headcount=int(round(hc))))

gl = pd.DataFrame(gl_rows)

# ----------------------------- BUDGET P&L ----------------------------------
bud_pl_rows = []
bs = bud_sales.merge(prod_df, on="Material")
bs["p"] = bs.Month.str[-2:].astype(int)
for p in range(1, 13):
    bp_all = bs[bs.p == p]
    for cc in COMPANIES:
        ships_cc = 0
        for pc in PCS:
            x = bp_all[(bp_all.CC == cc) & (bp_all.PC == pc)]
            if x.empty: continue
            rev = x.BudgetRevenueUSD.sum(); qty = x.BudgetQtyMT.sum()
            ships = math.ceil(qty / MT_PER_SHIPMENT); ships_cc += ships
            sh = PC_SHARE[cc][pc]
            lines = {
                "Gross Sales": rev, "Rebates & Discounts": rev * 0.038,
                "Raw Materials": (x.BudgetQtyMT * x.BPrice * x.RM).sum(),
                "Energy": qty * ENERGY_PER_MT[cc], "Direct Labour": FIXED[cc]["labour"] * sh,
                "Plant Overhead": FIXED[cc]["overhead"] * sh, "Freight Outbound": ships * FREIGHT_RATE[cc],
                "Inventory Adjustments": 0.0, "Selling": FIXED[cc]["selling"] * sh, "R&D": FIXED[cc]["rnd"] * sh,
                "G&A": FIXED[cc]["ga"] * sh, "Depreciation": FIXED[cc]["dep"] * sh}
            for ln, v in lines.items():
                # D2: DW stores ALL values positive (costs positive too); D3: PC without leading zeros
                bud_pl_rows.append(dict(Month=f"2026-{p:02d}", Entity=cc, ProfitCenter=pc, PLLine=ln,
                                        LineType=LINE_TYPE[ln], BudgetUSD=round(v, 2)))
        hc = {"US10": 640, "DE20": 410, "IN30": 230}[cc]
        ops_rows.append(dict(Month=f"2026-{p:02d}", Entity=cc, Scenario="Budget",
                             ShippedMT=round(bp_all[bp_all.CC == cc].BudgetQtyMT.sum(), 1), Shipments=ships_cc,
                             ProductionMT=round(bp_all[bp_all.CC == cc].BudgetQtyMT.sum() * 1.02, 1), Headcount=hc))
bud_pl = pd.DataFrame(bud_pl_rows)
ops = pd.DataFrame(ops_rows)

# ----------------------------- ACTUALS IN P&L SIGN ------------------------------
mapdf = pd.DataFrame(MAPPING, columns=["GLAccount", "PLLine", "PLSection", "LineOrder", "LineType"])
def actual_pl(glx, include_unmapped_as_freight=True):
    g = glx.copy()
    g["GL6"] = g.GLAccount.astype(int).astype(str)
    g["PC"] = g.ProfitCenter.astype(int).astype(str)
    m = mapdf.copy()
    if include_unmapped_as_freight:
        m = pd.concat([m, pd.DataFrame([("540050", "Freight Outbound", "Cost of Sales", 7, "Cost")], columns=m.columns)])
    g = g.merge(m, left_on="GL6", right_on="GLAccount", how="left", suffixes=("", "_m"))
    g["PLAmount"] = -g.AmountUSD  # SAP: credits negative -> P&L sign: favourable = positive
    return g

act = actual_pl(gl)
bud_pl["PLAmount"] = np.where(bud_pl.LineType == "Revenue", bud_pl.BudgetUSD, -bud_pl.BudgetUSD)
bud_pl["p"] = bud_pl.Month.str[-2:].astype(int)

# ----------------------------- FORECAST 6+6 (+ D5 total rows) ----------------------
fc_rows = []
for p in range(1, 13):
    for cc in COMPANIES:
        for pc in PCS:
            for ln in PL_LINES:
                if p <= 6:
                    a = act[(act.FiscalYear == 2026) & (act.Period == f"{p:03d}") & (act.CompanyCode == cc) &
                            (act.PC == pc) & (act.PLLine == ln)].PLAmount.sum()
                    v = a if LINE_TYPE[ln] == "Revenue" else -a
                else:
                    bv = bud_pl[(bud_pl.p == p) & (bud_pl.Entity == cc) & (bud_pl.ProfitCenter == pc) &
                                (bud_pl.PLLine == ln)].BudgetUSD.sum()
                    adj = {"Gross Sales": 1.01, "Raw Materials": 1.04, "Energy": 1.03, "Freight Outbound": 1.05}.get(ln, 1.0)
                    v = bv * adj
                if v == 0 and ln != "Inventory Adjustments": continue
                fc_rows.append(dict(Month=f"2026-{p:02d}", Entity=cc, ProfitCenter=pc, PLLine=ln,
                                    LineType=LINE_TYPE[ln], ForecastUSD=round(v, 2), Version="FC 6+6"))
fc = pd.DataFrame(fc_rows)
tot = fc.groupby(["Month", "Entity", "PLLine", "LineType", "Version"], as_index=False).ForecastUSD.sum()
tot["ProfitCenter"] = "ALL"   # D5 subtotal rows mixed into the export
fc_out = pd.concat([fc, tot[fc.columns]]).sort_values(["Month", "Entity", "ProfitCenter", "PLLine"]).reset_index(drop=True)

# ----------------------------- D4 duplicate block in billing ----------------------
dup = billing[(billing.FiscalYear == 2026) & (billing.Period == "009") & (billing.Material == "SA-240")]
billing_out = pd.concat([billing, dup]).reset_index(drop=True)

# ----------------------------- TB control + D10 late reversal -----------------------
tb = gl.groupby(["CompanyCode", "FiscalYear", "Period"], as_index=False).AmountUSD.sum()
tb["PL_NetIncome_USD"] = -tb.AmountUSD.round(2)
LATE_REV = 85_000
mask = (tb.CompanyCode == "IN30") & (tb.FiscalYear == 2026) & (tb.Period == "009")
tb.loc[mask, "PL_NetIncome_USD"] += LATE_REV
tb = tb.drop(columns="AmountUSD")
tb["SourceNote"] = "SAP P&L control total (fictional) - captured at period-end +3 days"

reextract = gl[(gl.FiscalYear == 2026) & (gl.Period == "009")].copy()
reextract = pd.concat([reextract, pd.DataFrame([dict(CompanyCode="IN30", FiscalYear=2026, Period="009",
    ProfitCenter=f"{1100:010d}", CostCenter="IN30-GA", GLAccount=f"{620200:010d}",
    GLDescription="Professional fees - accrual reversal (posted after first extract)", AmountUSD=-LATE_REV)])])

# ----------------------------- WRITE FILES ------------------------------------------
gl.to_csv(f"{OUT}/SAP_Extracts/SAP_GL_Actuals_FY2025_FY2026.csv", index=False)
billing_out.to_csv(f"{OUT}/SAP_Extracts/SAP_Billing_Sales_FY2025_FY2026.csv", index=False)
tb.to_csv(f"{OUT}/SAP_Extracts/SAP_TrialBalance_Control.csv", index=False)
reextract.to_csv(f"{OUT}/SAP_Extracts/SAP_GL_Actuals_Sep2026_REEXTRACT.csv", index=False)
bud_pl.drop(columns=["PLAmount", "p"]).to_csv(f"{OUT}/DW_Extracts/DW_Budget_PL_FY2026.csv", index=False)
bud_sales.to_csv(f"{OUT}/DW_Extracts/DW_Budget_Sales_FY2026.csv", index=False)
fc_out.to_csv(f"{OUT}/DW_Extracts/DW_Forecast_6plus6_FY2026.csv", index=False)
ops.to_csv(f"{OUT}/DW_Extracts/DW_Ops_Volumes_FY2026.csv", index=False)
mapdf.to_csv(f"{OUT}/Reference/GL_to_PL_Mapping.csv", index=False)
pd.DataFrame([dict(GLAccount=k, Description=v) for k, v in GL.items()]).to_csv(f"{OUT}/Reference/GL_Account_Master.csv", index=False)

# ----------------------------- ANSWER KEY -------------------------------------------
def r(x): return round(float(x), 2)
S = f"{CLOSE_P:03d}"
sep_act = act[(act.FiscalYear == 2026) & (act.Period == S)]
sep_py = act[(act.FiscalYear == 2025) & (act.Period == S)]
sep_bud = bud_pl[bud_pl.p == CLOSE_P]
sep_fc = fc[fc.Month == "2026-09"].copy()
sep_fc["PLAmount"] = np.where(sep_fc.LineType == "Revenue", sep_fc.ForecastUSD, -sep_fc.ForecastUSD)

def by_line(df, col="PLAmount"):
    return df.groupby("PLLine")[col].sum().reindex(PL_LINES).fillna(0)
A, B, PY, F = by_line(sep_act), by_line(sep_bud), by_line(sep_py), by_line(sep_fc)
var_table = []
for ln in PL_LINES:
    var_table.append(dict(PLLine=ln, Actual=r(A[ln]), Budget=r(B[ln]), Var_vs_Budget=r(A[ln] - B[ln]),
                          VarPct_vs_Budget=(r((A[ln] - B[ln]) / abs(B[ln]) * 100) if B[ln] else None),
                          Forecast=r(F[ln]), Var_vs_Forecast=r(A[ln] - F[ln]), PriorYear=r(PY[ln]),
                          Var_vs_PY=r(A[ln] - PY[ln])))
def sub(d, lines): return sum(d[l] for l in lines)
NR = ["Gross Sales", "Rebates & Discounts"]
COS = ["Raw Materials", "Energy", "Direct Labour", "Plant Overhead", "Freight Outbound", "Inventory Adjustments"]
OPX = ["Selling", "R&D", "G&A", "Depreciation"]
subtotals = {}
for name, lines in [("Net Revenue", NR), ("Gross Margin", NR + COS), ("EBIT", PL_LINES)]:
    subtotals[name] = dict(Actual=r(sub(A, lines)), Budget=r(sub(B, lines)), Forecast=r(sub(F, lines)),
                           PriorYear=r(sub(PY, lines)), Var_vs_Budget=r(sub(A, lines) - sub(B, lines)))

# EBIT variance by BU
bu = {}
for pc, name in PCS.items():
    a = sep_act[sep_act.PC == pc].PLAmount.sum(); b = sep_bud[sep_bud.ProfitCenter == pc].PLAmount.sum()
    bu[name] = dict(Actual=r(a), Budget=r(b), Var=r(a - b))

# Materiality (|var| >= 3% AND >= 250,000)
material = [v["PLLine"] for v in var_table if v["VarPct_vs_Budget"] is not None and
            abs(v["VarPct_vs_Budget"]) >= 3 and abs(v["Var_vs_Budget"]) >= 250_000]
material_inc_noBudget = material + [v["PLLine"] for v in var_table if v["Budget"] == 0 and abs(v["Var_vs_Budget"]) >= 250_000]

# PVM (Sep, gross sales, product grain, billing de-duplicated)
bill_sep = billing[(billing.FiscalYear == 2026) & (billing.Period == S)].groupby(["Material"], as_index=False)[["BilledQtyMT", "NetRevenueUSD"]].sum()
bud_sep = bud_sales[bud_sales.Month == "2026-09"].groupby("Material", as_index=False)[["BudgetQtyMT", "BudgetRevenueUSD"]].sum()
pv = bud_sep.merge(bill_sep, on="Material", how="outer").fillna(0).merge(prod_df[["Material", "PC"]], on="Material")
def pvm(df):
    budgeted = df[df.BudgetQtyMT > 0].copy()
    newp = df[df.BudgetQtyMT == 0]
    budgeted["AP"] = budgeted.NetRevenueUSD / budgeted.BilledQtyMT
    budgeted["BP"] = budgeted.BudgetRevenueUSD / budgeted.BudgetQtyMT
    budgeted["BMix"] = budgeted.BudgetQtyMT / budgeted.BudgetQtyMT.sum()
    AQt, BQt = budgeted.BilledQtyMT.sum(), budgeted.BudgetQtyMT.sum()
    price = ((budgeted.AP - budgeted.BP) * budgeted.BilledQtyMT).sum()
    mix = ((budgeted.BilledQtyMT - AQt * budgeted.BMix) * budgeted.BP).sum()
    vol = (AQt - BQt) * (budgeted.BMix * budgeted.BP).sum()
    new = newp.NetRevenueUSD.sum()
    total = df.NetRevenueUSD.sum() - df.BudgetRevenueUSD.sum()
    return dict(Price=r(price), Mix=r(mix), Volume=r(vol), NewProducts=r(new), Total=r(total),
                Check=r(price + mix + vol + new - total))
pvm_total = pvm(pv)
pvm_bu = {PCS[pc]: pvm(pv[pv.PC == pc]) for pc in PCS}
dup_rev = r(dup.NetRevenueUSD.sum())

# Freight drivers DE20 Sep
def ops_get(ent, scen, col): return float(ops[(ops.Entity == ent) & (ops.Scenario == scen) & (ops.Month == "2026-09")][col].iloc[0])
fr = {}
for ent in COMPANIES:
    a_cost = -sep_act[(sep_act.CompanyCode == ent) & (sep_act.GL6 == "540000")].PLAmount.sum()
    exp_cost = -sep_act[(sep_act.CompanyCode == ent) & (sep_act.GL6 == "540050")].PLAmount.sum()
    b_cost = sep_bud[(sep_bud.Entity == ent) & (sep_bud.PLLine == "Freight Outbound")].BudgetUSD.sum()
    a_sh, b_sh = ops_get(ent, "Actual", "Shipments"), ops_get(ent, "Budget", "Shipments")
    b_rate, a_rate = b_cost / b_sh, a_cost / a_sh
    fr[ent] = dict(ActualStdFreight=r(a_cost), Expedited=r(exp_cost), Budget=r(b_cost), ActualShipments=a_sh,
                   BudgetShipments=b_sh, BudgetRate=r(b_rate), ActualRate=r(a_rate),
                   VolumeEffect=r((a_sh - b_sh) * b_rate), RateEffect=r((a_rate - b_rate) * a_sh),
                   TotalAdverse=r(a_cost + exp_cost - b_cost))

d1 = gl[gl.GLAccount.astype(int) == 540050]
checks = dict(
    D1_unmapped_rows=int(len(d1)), D1_unmapped_amount=r(d1.AmountUSD.sum()),
    D1_by_period={k: r(v) for k, v in d1.groupby("Period").AmountUSD.sum().items()},
    D4_duplicate_rows=int(len(dup)), D4_duplicate_revenue=dup_rev,
    D5_total_rows=int(len(tot)), D5_naive_sep_forecast_gross_sales=r(fc_out[(fc_out.Month == "2026-09") & (fc_out.PLLine == "Gross Sales")].ForecastUSD.sum()),
    D5_correct_sep_forecast_gross_sales=r(F["Gross Sales"]),
    D10_IN30_sep_difference=LATE_REV,
    gl_rows=len(gl), billing_rows_with_dup=len(billing_out), budget_pl_rows=len(bud_pl), forecast_rows=len(fc_out),
    sep_gl_total_net_income=r(act[(act.FiscalYear == 2026) & (act.Period == S)].PLAmount.sum()),
    D2_naive_gross_sales_var_if_sign_not_flipped=r(-A["Gross Sales"] - B["Gross Sales"]),
)
ytd = {}
ya = act[(act.FiscalYear == 2026) & (act.Period.astype(int) <= CLOSE_P)].PLAmount.sum()
yb = bud_pl[bud_pl.p <= CLOSE_P].PLAmount.sum()
ytd["EBIT"] = dict(Actual=r(ya), Budget=r(yb), Var=r(ya - yb))

key = dict(close="Sep 2026 (FY2026 P009)", currency="USD", materiality="|var| >= 3% AND >= USD 250,000",
           variance_table=var_table, subtotals=subtotals, ebit_by_bu=bu, material_lines=material,
           material_lines_incl_no_budget=material_inc_noBudget, pvm_total=pvm_total, pvm_by_bu=pvm_bu,
           freight=fr, checks=checks, ytd=ytd, write_off=1_200_000, pc_share=PC_SHARE,
           companies=COMPANIES, profit_centers=PCS, pl_lines=PL_LINES,
           pvm_table=pv.assign(PC=pv.PC.map(PCS)).round(2).to_dict(orient="records"))
json.dump(key, open(os.path.join(ROOT, "build", "answer_key.json"), "w"), indent=2, default=float)
print(json.dumps({k: key[k] for k in ["subtotals", "ebit_by_bu", "material_lines", "material_lines_incl_no_budget", "pvm_total", "checks", "ytd"]}, indent=1, default=float))
print(json.dumps(key["pvm_by_bu"], indent=1)); print(json.dumps(fr, indent=1))
for v in var_table: print(v)

# ---- Raw material split (Sep): volume/mix at budget cost per MT vs rate (siloxane index) ----
bsep = billing[(billing.FiscalYear == 2026) & (billing.Period == S)].merge(prod_df, on="Material")
rm_at_budget_rate = float((bsep.BilledQtyMT * bsep.BPrice * bsep.RM).sum())
rm_actual = float(-A["Raw Materials"]); rm_budget = float(-B["Raw Materials"])
key["raw_materials"] = dict(Actual=r(rm_actual), Budget=r(rm_budget), AtBudgetRateOnActualVolume=r(rm_at_budget_rate),
                           VolumeMixEffect=r(-(rm_at_budget_rate - rm_budget)), RateEffect=r(-(rm_actual - rm_at_budget_rate)),
                           SiloxaneIndexSep=1.07)
json.dump(key, open(os.path.join(ROOT, "build", "answer_key.json"), "w"), indent=2, default=float)
print("RM", key["raw_materials"])

# ---- Material master standard RM cost (SAP extract) ----
std = prod_df.assign(StdRMCostUSDperMT=(prod_df.BPrice * prod_df.RM).round(2))
desc = {x[0]: x[1] for x in PRODUCTS}
std = std.assign(MaterialDesc=std.Material.map(desc), ProfitCenter=std.PC.map(lambda p: f"{int(p):010d}"),
                 CompanyCode=std.CC)[["Material", "MaterialDesc", "CompanyCode", "ProfitCenter", "StdRMCostUSDperMT"]]
std.to_csv(f"{OUT}/SAP_Extracts/SAP_Material_StdCost.csv", index=False)
# check std-based RM equals answer key
chk = (bsep.BilledQtyMT * bsep.Material.map(dict(zip(std.Material, std.StdRMCostUSDperMT)))).sum()
print("STD RM at actual vol", round(chk, 2), "key", key["raw_materials"]["AtBudgetRateOnActualVolume"])
