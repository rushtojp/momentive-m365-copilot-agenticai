import pandas as pd, sys, runpy, json
from openpyxl import load_workbook
wb = load_workbook(sys.argv[1], data_only=True); ws = wb["PVM"]
def xl(ref, headers=True):
    rows = [[c.value for c in r] for r in ws["A4:F17"]]
    return pd.DataFrame(rows[1:], columns=rows[0])
code = open("kit/02_Labs/code/lab4_pvm_python_in_excel.py").read()
ns = {"xl": xl, "pd": pd}; exec(code, ns)
print(ns["result"].round(2).to_string(index=False))
k = json.load(open("build/answer_key.json"))["pvm_total"]
r = dict(zip(ns["result"].Component, ns["result"].USD))
assert abs(r["Price"]-k["Price"])<0.01 and abs(r["Mix"]-k["Mix"])<0.01 and abs(r["Volume"]-k["Volume"])<0.01 and abs(r["New products"]-k["NewProducts"])<0.01 and r["Check (must be 0)"]==0
print("LAB4 PYTHON MATCHES ANSWER KEY")
