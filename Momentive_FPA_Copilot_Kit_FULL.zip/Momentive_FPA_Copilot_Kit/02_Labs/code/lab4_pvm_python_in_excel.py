# Lab 4 - Price / Volume / Mix in Python in Excel
# Paste into a Python in Excel cell (=PY) on a new sheet named PVM_Python.
# Reads the PVM sheet header row (row 4) and 13 product rows (5-17), columns A:F.
df = xl("PVM!A4:F17", headers=True)
df.columns = ["Material", "BU", "BQ", "BRev", "AQ", "ARev"]

budgeted = df[df["BQ"] > 0].copy()          # products with a budget
new = df[df["BQ"] == 0]                     # new products (no budget) - planted defect D6

budgeted["BP"] = budgeted["BRev"] / budgeted["BQ"]          # budget price per MT
budgeted["AP"] = budgeted["ARev"] / budgeted["AQ"]          # actual price per MT
budgeted["BMix"] = budgeted["BQ"] / budgeted["BQ"].sum()    # budget mix share

AQt, BQt = budgeted["AQ"].sum(), budgeted["BQ"].sum()
price  = ((budgeted["AP"] - budgeted["BP"]) * budgeted["AQ"]).sum()
mix    = ((budgeted["AQ"] - AQt * budgeted["BMix"]) * budgeted["BP"]).sum()
volume = (AQt - BQt) * (budgeted["BMix"] * budgeted["BP"]).sum()
newp   = new["ARev"].sum()
total  = df["ARev"].sum() - df["BRev"].sum()

result = pd.DataFrame({
    "Component": ["Price", "Mix", "Volume", "New products", "Total variance", "Check (must be 0)"],
    "USD": [price, mix, volume, newp, total, round(price + mix + volume + newp - total, 2)],
})
result
