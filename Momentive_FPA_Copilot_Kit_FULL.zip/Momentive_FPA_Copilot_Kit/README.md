# Momentive FP&A — Copilot-assisted variance analysis lab kit

**All data in this kit is fictional teaching data.** Company codes, plants, products and figures are invented. It is shaped like a silicones manufacturer's month-end close but is not Momentive data.

Prepared by Jayaprakash Balakrishnan, Aarvi Learning Solutions. Version 1.0, October 2026. Close month in all labs: September 2026 (FY2026 P009).

## Folder map

| Folder | Contents | Give to participants? |
|---|---|---|
| `01_Presentations/` | Workshop deck (23 slides, speaker notes). Section 03 "Debrief" reveals answers; show it after Lab 5. | Deck after the workshop |
| `02_Labs/` | Participant Lab Guide (Labs 0–8 + Capstone), `code/lab4_pvm_python_in_excel.py` | Yes |
| `02_Labs/Facilitator/` | Facilitator Guide: answer key, planted-defect map, run sheet, dry-run checklist | **No** |
| `03_Sample_Data/` | SAP and DW CSV extracts, mapping, standard cost, TB control, Sep re-extract, close/materiality note | Yes |
| `04_Workbooks/` | `STARTER` (participants) and `SOLUTION` (facilitator; has an AnswerKey sheet) | STARTER only |
| `05_Prompt_Library/` | 46 CRAFT prompts (L1–L4), level ladder, anti-patterns, verification register, prompt log | Yes |
| `06_Build_Source/` | Generators: data, workbooks, prompt library, guides, deck; `answer_key.json` | **No** |

## Verification performed at build

- Every expected value (38 items) was computed independently in Python and compared with the SOLUTION workbook's formulas: zero differences.
- STARTER and SOLUTION recalculate with zero formula errors.
- The Lab 4 Python code was executed against both workbooks and reproduces the price/volume/mix answer key (check = 0).
- The capstone re-extract makes all trial-balance checks pass; September EBIT becomes 7,589,520.58.
- Copilot behaviour itself was **not** run here (no tenant access). Version-sensitive features are listed in the Verification Register; re-check them in the client tenant during the dry run.

## Rebuilding

```
python3 06_Build_Source/gen_data.py
python3 06_Build_Source/build_workbooks.py
python3 06_Build_Source/build_library.py
node 06_Build_Source/build_lab_guide.js
node 06_Build_Source/build_facilitator.js
node 06_Build_Source/build_deck.js
```

The builders expect the original layout (`build/` beside `kit/`); adjust paths if you move them. Edit content in `gen_data.py` or `prompts.py`, never in the outputs.
